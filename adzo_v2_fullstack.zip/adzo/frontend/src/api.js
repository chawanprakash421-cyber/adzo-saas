const BASE = import.meta.env.VITE_API_URL || '/api';

const getToken = () => localStorage.getItem('adzo_token');

const req = async (method, path, body) => {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
};

// ── AUTH ──────────────────────────────────────────
export const authAPI = {
  login: (email, password) => req('POST', '/auth/login', { email, password }),
  register: (fields) => req('POST', '/auth/register', fields),
  me: () => req('GET', '/auth/me'),
  updateProfile: (fields) => req('PUT', '/auth/profile', fields),
};

// ── LEADS ─────────────────────────────────────────
export const leadsAPI = {
  list: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return req('GET', `/leads${qs ? '?' + qs : ''}`);
  },
  get: (id) => req('GET', `/leads/${id}`),
  create: (data) => req('POST', '/leads', data),
  update: (id, data) => req('PUT', `/leads/${id}`, data),
  delete: (id) => req('DELETE', `/leads/${id}`),
  followup: () => req('GET', '/leads/filter/followup'),
  stats: () => req('GET', '/leads/stats/summary'),
};

// ── CONTENT / AI ──────────────────────────────────
export const contentAPI = {
  generate: (type, context, tone) => req('POST', '/content/generate', { type, context, tone }),
  priya: (message, history) => req('POST', '/content/priya', { message, history }),
  list: () => req('GET', '/content'),
  update: (id, data) => req('PUT', `/content/${id}`, data),
};

// ── CAMPAIGNS ─────────────────────────────────────
export const campaignsAPI = {
  list: () => req('GET', '/campaigns'),
  create: (data) => req('POST', '/campaigns', data),
  update: (id, data) => req('PUT', `/campaigns/${id}`, data),
  delete: (id) => req('DELETE', `/campaigns/${id}`),
};

// ── WALLET ────────────────────────────────────────
export const walletAPI = {
  get: () => req('GET', '/wallet'),
  createOrder: (amount) => req('POST', '/wallet/order', { amount }),
  verify: (data) => req('POST', '/wallet/verify', data),
  plans: () => req('GET', '/wallet/plans'),
};

// ── ADMIN ─────────────────────────────────────────
export const adminAPI = {
  overview: () => req('GET', '/admin/overview'),
  businesses: () => req('GET', '/admin/businesses'),
  users: () => req('GET', '/admin/users'),
  revenue: () => req('GET', '/admin/revenue'),
  system: () => req('GET', '/admin/system'),
  updateBusiness: (id, data) => req('PUT', `/admin/businesses/${id}/plan`, data),
};
