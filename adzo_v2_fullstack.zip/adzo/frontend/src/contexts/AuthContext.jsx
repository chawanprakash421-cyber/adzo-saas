import { createContext, useContext, useState, useEffect } from 'react';
import { authAPI } from '../api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [business, setBusiness] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('adzo_token');
    if (token) {
      authAPI.me()
        .then(({ user, business }) => { setUser(user); setBusiness(business); })
        .catch(() => { localStorage.removeItem('adzo_token'); })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (email, password) => {
    const { token, user } = await authAPI.login(email, password);
    localStorage.setItem('adzo_token', token);
    setUser(user);
    const { business } = await authAPI.me();
    setBusiness(business);
    return user;
  };

  const register = async (fields) => {
    const { token, user } = await authAPI.register(fields);
    localStorage.setItem('adzo_token', token);
    setUser(user);
    const { business } = await authAPI.me();
    setBusiness(business);
    return user;
  };

  const logout = () => {
    localStorage.removeItem('adzo_token');
    setUser(null); setBusiness(null);
  };

  return (
    <AuthContext.Provider value={{ user, business, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
