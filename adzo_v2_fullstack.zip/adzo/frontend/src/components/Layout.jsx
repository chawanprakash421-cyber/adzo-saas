import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import PriyaChat from './PriyaChat';

const CLIENT_NAV = [
  { label: 'Home', icon: '🏠', path: '/' },
  { label: 'All Leads', icon: '🎯', path: '/leads', badge: null },
  { label: 'Follow-Up Needed', icon: '⏰', path: '/followup', badge: '7', badgeColor: 'amber' },
  { label: 'Campaigns', icon: '📢', path: '/campaigns' },
  { label: 'Content Studio', icon: '✍️', path: '/content' },
  { label: 'My Listings', icon: '🏘️', path: '/listings' },
  { label: 'Performance Report', icon: '📊', path: '/analytics' },
  { label: 'Reviews Manager', icon: '⭐', path: '/reviews' },
  { label: 'Wallet & Plans', icon: '💳', path: '/wallet' },
  { label: 'Help & Support', icon: '🆘', path: '/support' },
];

const ADMIN_NAV = [
  { label: 'Platform Overview', icon: '📊', path: '/admin' },
  { label: 'All Users', icon: '👤', path: '/admin/users' },
  { label: 'Revenue', icon: '💰', path: '/admin/revenue' },
  { label: 'System Health', icon: '🔌', path: '/admin/system' },
];

const PAGE_TITLES = {
  '/': '🏠 Home Dashboard',
  '/leads': '🎯 All Leads',
  '/followup': '⏰ Follow-Up Needed',
  '/campaigns': '📢 Campaigns',
  '/content': '✍️ Content Studio',
  '/listings': '🏘️ My Listings',
  '/analytics': '📊 Performance Report',
  '/reviews': '⭐ Reviews Manager',
  '/wallet': '💳 Wallet & Plans',
  '/support': '🆘 Help & Support',
  '/admin': '📊 Platform Overview',
  '/admin/users': '👤 All Users',
  '/admin/revenue': '💰 Revenue',
  '/admin/system': '🔌 System Health',
};

export default function Layout() {
  const { user, business, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [view, setView] = useState(user?.role === 'admin' ? 'admin' : 'client');
  const [priyaOpen, setPriyaOpen] = useState(false);

  const nav = view === 'admin' ? ADMIN_NAV : CLIENT_NAV;
  const title = PAGE_TITLES[location.pathname] || 'Adzo';

  return (
    <div className="app">
      {/* ── SIDEBAR ── */}
      <div className="sidebar">
        <div className="slogo">
          <div className="slogo-icon">AZ</div>
          <div>
            <div className="slogo-text">Adzo</div>
            <div className="slogo-sub">AI Growth Platform</div>
          </div>
        </div>

        {/* View switcher (only show if admin) */}
        {user?.role === 'admin' && (
          <div className="view-sw">
            <button
              className={`vsw-btn${view === 'client' ? ' active' : ''}`}
              onClick={() => { setView('client'); navigate('/'); }}>
              Client
            </button>
            <button
              className={`vsw-btn${view === 'admin' ? ' active' : ''}`}
              onClick={() => { setView('admin'); navigate('/admin'); }}>
              Admin
            </button>
          </div>
        )}

        <div className="slabel">{view === 'admin' ? 'Admin Panel' : 'Main Menu'}</div>

        <nav id="mainNav">
          {nav.map(item => (
            <button
              key={item.path}
              className={`nitem${location.pathname === item.path ? ' active' : ''}`}
              onClick={() => navigate(item.path)}>
              <span className="nico">{item.icon}</span>
              {item.label}
              {item.badge && <span className={`nbadge${item.badgeColor ? ' ' + item.badgeColor : ''}`}>{item.badge}</span>}
            </button>
          ))}
        </nav>

        <div className="sbot">
          <div className="upill" onClick={logout} title="Click to logout">
            <div className="ava">{(user?.name || 'U')[0].toUpperCase()}</div>
            <div>
              <div className="uname">{user?.name || 'User'}</div>
              <div className="urole">{business?.name || 'Adzo'} · {user?.plan || 'Trial'}</div>
            </div>
          </div>
        </div>
      </div>

      {/* ── MAIN ── */}
      <div className="main">
        <div className="topbar">
          <div className="tbar-title">{title}</div>
          <button className="btn btn-sm" style={{ background: 'rgba(124,92,252,.1)', color: 'var(--accent)', border: '1px solid rgba(124,92,252,.2)', fontSize: '11px' }} onClick={() => setPriyaOpen(v => !v)}>
            🤖 Ask Priya
          </button>
          <div className="ico-btn" onClick={logout} title="Logout">
            <span>👤</span>
          </div>
        </div>

        <div className="content">
          <Outlet />
        </div>
      </div>

      {/* ── PRIYA CHAT ── */}
      {priyaOpen && <PriyaChat onClose={() => setPriyaOpen(false)} />}
    </div>
  );
}
