import { useState, useRef, useEffect } from 'react';
import { contentAPI } from '../api';

export default function PriyaChat({ onClose }) {
  const [msgs, setMsgs] = useState([
    { role: 'ai', text: 'Hi! 👋 I\'m Priya, your AI business manager. How can I help you today? Try asking "How are my ads?" or "Write a WhatsApp for new leads".' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs]);

  const send = async () => {
    const msg = input.trim();
    if (!msg || loading) return;
    setInput('');
    setMsgs(m => [...m, { role: 'user', text: msg }]);
    setLoading(true);
    try {
      const history = msgs
        .filter(m => m.role !== 'ai' || msgs.indexOf(m) > 0)
        .slice(-6)
        .map(m => ({ role: m.role === 'ai' ? 'assistant' : 'user', content: m.text }));
      const { reply } = await contentAPI.priya(msg, history);
      setMsgs(m => [...m, { role: 'ai', text: reply }]);
    } catch {
      setMsgs(m => [...m, { role: 'ai', text: "Sorry, I'm having a moment. Please try again 🙏" }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="priya-chat-overlay">
      <div className="pco-header">
        <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'rgba(255,255,255,.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>🤖</div>
        <div>
          <div style={{ fontFamily: 'Syne,sans-serif', fontWeight: 800, fontSize: 13 }}>Priya</div>
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,.7)', display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: '#34d399' }} />
            Online · AI Business Manager
          </div>
        </div>
        <button onClick={onClose}>✕</button>
      </div>

      <div className="pco-msgs">
        {msgs.map((m, i) => (
          <div key={i} className={`pcm ${m.role}`}>{m.text}</div>
        ))}
        {loading && <div className="pcm ai" style={{ color: 'var(--muted)' }}>Priya is thinking… ✨</div>}
        <div ref={bottomRef} />
      </div>

      <div className="pco-input-row">
        <input
          className="pco-input"
          placeholder="Ask Priya anything…"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
        />
        <button className="btn btn-p btn-sm" onClick={send} disabled={loading}>
          {loading ? <span className="spinner" style={{ width: 12, height: 12 }} /> : '→'}
        </button>
      </div>
    </div>
  );
}
