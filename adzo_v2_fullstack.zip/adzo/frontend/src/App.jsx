import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Home from './pages/Home';
import Leads from './pages/Leads';
import FollowUp from './pages/FollowUp';
import ContentStudio from './pages/ContentStudio';
import Campaigns from './pages/Campaigns';
import Analytics from './pages/Analytics';
import Listings from './pages/Listings';
import Reviews from './pages/Reviews';
import Wallet from './pages/Wallet';
import Support from './pages/Support';
import AdminOverview from './pages/admin/AdminOverview';
import AdminUsers from './pages/admin/AdminUsers';
import AdminRevenue from './pages/admin/AdminRevenue';
import AdminSystem from './pages/admin/AdminSystem';
import './index.css';

function Guard({ children, adminOnly = false }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-full"><div className="spinner" />Loading Adzo…</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user.role !== 'admin') return <Navigate to="/" replace />;
  return children;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/" element={<Guard><Layout /></Guard>}>
        <Route index element={<Home />} />
        <Route path="leads" element={<Leads />} />
        <Route path="followup" element={<FollowUp />} />
        <Route path="content" element={<ContentStudio />} />
        <Route path="campaigns" element={<Campaigns />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="listings" element={<Listings />} />
        <Route path="reviews" element={<Reviews />} />
        <Route path="wallet" element={<Wallet />} />
        <Route path="support" element={<Support />} />
        <Route path="admin" element={<Guard adminOnly><AdminOverview /></Guard>} />
        <Route path="admin/users" element={<Guard adminOnly><AdminUsers /></Guard>} />
        <Route path="admin/revenue" element={<Guard adminOnly><AdminRevenue /></Guard>} />
        <Route path="admin/system" element={<Guard adminOnly><AdminSystem /></Guard>} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
