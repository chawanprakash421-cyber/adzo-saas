import { useState, useEffect } from 'react';
import { contentAPI } from '../api';

const TYPES = [
  { key: 'whatsapp', label: '💬 WhatsApp Message', color: 'var(--green)' },
  { key: 'instagram', label: '📸 Instagram Caption', color: '#e879f9' },
  { key: 'google_ad', label: '🔍 Google Ad', color: 'var(--blue)' },
  { key: 'email', label: '📧 Email Newsletter', color: 'var(--amber)' },
  { key: 'facebook_reel', label: '🎥 Facebook Reel Script', color: 'var(--orange)' },
  { key: 'follow_up_script', label: '📞 Call Script', color: 'var(--accent)' },
];

export default function ContentStudio() {
  const [library, setLibrary] = useState([]);
  const [type, setType] = useState('whatsapp');
  const [context, setContext] = useState('');
  const [tone, setTone] = useState('friendly');
  const [generated, setGenerated] = useState('');
  const [loading, setLoading] = useState(false);
  const [libLoading, setLibLoading] = useState(true);

  useEffect(() => {
    contentAPI.list().then(r => { setLibrary(r.items || []); setLibLoading(false); }).catch(() => setLibLoading(false));
  }, []);

  const generate = async () => {
    if (!context.trim()) return;
    setLoading(true); setGenerated('');
    try {
      const { content, id } = await contentAPI.generate(type, context, tone);
      setGenerated(content);
      setLibrary(l => [{ id, type, content, status: 'draft', created_at: new Date().toISOString() }, ...l]);
    } catch (e) {
      setGenerated('⚠ Generation failed: ' + e.message);
    }
    setLoading(false);
  };

  return (
    <div className="page-anim">
      <div className="ph">
        <h2>✍️ Content Studio</h2>
        <p>Let AI write your posts, ads and messages. You just approve and post.</p>
      </div>

      <div className="section-intro">
        <strong>You don't need to write anything!</strong> Just tell the AI what you want — like "Write an Instagram post for my 2BHK in Gachibowli" — and it creates ready-to-post content instantly.
      </div>

      {/* Generator */}
      <div className="gen-form">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <label>Content Type</label>
            <select value={type} onChange={e => setType(e.target.value)}>
              {TYPES.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
            </select>
          </div>
          <div>
            <label>Tone</label>
            <select value={tone} onChange={e => setTone(e.target.value)}>
              {['friendly','professional','urgent','festive','casual'].map(t => (
                <option key={t} value={t}>{t.charAt(0).toUpperCase()+t.slice(1)}</option>
              ))}
            </select>
          </div>
        </div>
        <label>Tell AI what to write about</label>
        <textarea
          value={context}
          onChange={e => setContext(e.target.value)}
          placeholder="e.g. Write a WhatsApp for Vinay Kumar who is interested in 3BHK in Gachibowli, budget 90L. He enquired 3 days ago and hasn't replied."
          rows={3}
        />
        <div style={{ marginTop: 12, display: 'flex', gap: 10 }}>
          <button className="btn btn-p" onClick={generate} disabled={loading || !context.trim()}>
            {loading ? <><span className="spinner" style={{ width: 12, height: 12 }} /> &nbsp; Priya is writing…</> : '🤖 Generate with AI'}
          </button>
          <button className="btn btn-o" onClick={() => { setContext(''); setGenerated(''); }}>Clear</button>
        </div>
      </div>

      {/* Generated Output */}
      {generated && (
        <div className="card" style={{ marginBottom: 18, border: '1px solid rgba(124,92,252,.25)', background: 'rgba(124,92,252,.03)' }}>
          <div className="card-hd">
            <div className="card-title">✨ Priya wrote this for you</div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="btn btn-g btn-sm" onClick={() => { navigator.clipboard.writeText(generated); }}>Copy</button>
              <button className="btn btn-p btn-sm">Use This →</button>
            </div>
          </div>
          <div style={{ fontSize: 13, lineHeight: 1.7, whiteSpace: 'pre-wrap', color: 'var(--text)' }}>{generated}</div>
        </div>
      )}

      {/* Library */}
      <div className="card-hd" style={{ marginBottom: 14 }}>
        <div className="card-title">📚 Content Library</div>
        <span style={{ fontSize: 11, color: 'var(--muted)' }}>{library.length} pieces created</span>
      </div>

      {libLoading ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--muted)' }}><span className="spinner" /></div>
      ) : library.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--muted)', fontSize: 13 }}>
          No content yet — generate your first piece above! 👆
        </div>
      ) : (
        <div className="cg">
          {library.map((item) => {
            const t = TYPES.find(t => t.key === item.type);
            return (
              <div className="cc" key={item.id}>
                <span className="cctype" style={{ color: t?.color || 'var(--accent)' }}>{t?.label || item.type}</span>
                <div className="cctitle" style={{ whiteSpace: 'pre-wrap', fontSize: 11 }}>
                  {item.content?.length > 200 ? item.content.slice(0, 200) + '…' : item.content}
                </div>
                <div style={{ display: 'flex', gap: 6, justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className={`badge ${item.status === 'published' ? 'bactive' : 'bnew'}`}>
                    {item.status === 'published' ? '● Live' : 'Draft'}
                  </span>
                  <button className="btn btn-o btn-sm" onClick={() => navigator.clipboard.writeText(item.content)}>Copy</button>
                </div>
              </div>
            );
          })}

          {/* New card */}
          <div className="cc" style={{ border: '1px dashed var(--border)', background: 'transparent', justifyContent: 'center', alignItems: 'center', minHeight: 100, cursor: 'pointer' }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
              <div style={{ fontSize: 22, marginBottom: 6 }}>+</div>
              <div style={{ fontSize: 11 }}>Ask AI to write something new</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
