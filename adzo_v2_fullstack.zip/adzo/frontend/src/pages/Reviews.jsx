export { Reviews as default } from './OtherPages';
