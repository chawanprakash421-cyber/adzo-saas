export { Campaigns as default } from './OtherPages';
