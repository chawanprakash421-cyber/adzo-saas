import { useState, useEffect } from 'react';
import { leadsAPI } from '../api';

const STATUS_COLORS = { new: 'bnew', contacted: 'bactive', converted: 'bconverted', lost: 'binactive' };
const SOURCE_COLORS = { google: 'bgoogle', meta: 'bmeta', whatsapp: 'bwa', organic: 'borganic', manual: 'badmin' };
const AVATARS = ['#7c5cfc','#f59e0b','#38bdf8','#34d399','#f97316','#e879f9'];

export default function Leads() {
  const [leads, setLeads] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [newLead, setNewLead] = useState({ name: '', phone: '', interest: '', source: 'manual', budget: '', locality: '' });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (statusFilter) params.status = statusFilter;
      const data = await leadsAPI.list(params);
      setLeads(data.leads || []);
      setTotal(data.total || 0);
    } catch {}
    setLoading(false);
  };

  useEffect(() => { load(); }, [search, statusFilter]);

  const addLead = async () => {
    if (!newLead.name || !newLead.phone) return;
    setSaving(true);
    try {
      const { lead } = await leadsAPI.create(newLead);
      setLeads(l => [lead, ...l]);
      setShowAdd(false);
      setNewLead({ name: '', phone: '', interest: '', source: 'manual', budget: '', locality: '' });
    } catch {}
    setSaving(false);
  };

  const updateStatus = async (id, status) => {
    await leadsAPI.update(id, { status });
    setLeads(ls => ls.map(l => l.id === id ? { ...l, status } : l));
  };

  const daysSince = (d) => {
    if (!d) return '';
    const n = Math.floor((Date.now() - new Date(d)) / 86400000);
    return n === 0 ? 'Today' : n === 1 ? 'Yesterday' : `${n}d ago`;
  };

  return (
    <div className="page-anim">
      <div className="ph">
        <h2>🎯 All Leads</h2>
        <p>Every person who has enquired about your business — {total} total leads</p>
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 18, alignItems: 'center', flexWrap: 'wrap' }}>
        <input
          style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--rsm)', padding: '7px 12px', fontSize: 12, width: 200 }}
          placeholder="🔍 Search by name…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        {['', 'new', 'contacted', 'converted', 'lost'].map(s => (
          <button key={s} className={`btn btn-sm ${statusFilter === s ? 'btn-p' : 'btn-o'}`} onClick={() => setStatusFilter(s)}>
            {s === '' ? 'All' : s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
        <button className="btn btn-p btn-sm" style={{ marginLeft: 'auto' }} onClick={() => setShowAdd(v => !v)}>+ Add Lead</button>
      </div>

      {/* Add Lead Form */}
      {showAdd && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-hd"><div className="card-title">Add New Lead</div></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10 }}>
            {[['name','Name *','Sachin Chavan'],['phone','Phone *','+91 98765 43210'],['locality','Locality','Gachibowli'],['interest','Interest','2BHK, 3BHK'],['budget','Budget','₹80L']].map(([k,l,p]) => (
              <div key={k}>
                <div style={{ fontSize: 11, color: 'var(--muted)', fontWeight: 600, marginBottom: 4 }}>{l}</div>
                <input style={{ width: '100%', border: '1px solid var(--border)', borderRadius: 'var(--rsm)', padding: '8px 10px', fontSize: 12 }}
                  placeholder={p} value={newLead[k]} onChange={e => setNewLead(n => ({ ...n, [k]: e.target.value }))} />
              </div>
            ))}
            <div>
              <div style={{ fontSize: 11, color: 'var(--muted)', fontWeight: 600, marginBottom: 4 }}>Source</div>
              <select style={{ width: '100%', border: '1px solid var(--border)', borderRadius: 'var(--rsm)', padding: '8px 10px', fontSize: 12 }}
                value={newLead.source} onChange={e => setNewLead(n => ({ ...n, source: e.target.value }))}>
                {['manual','google','meta','whatsapp','organic'].map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button className="btn btn-p" onClick={addLead} disabled={saving}>{saving ? 'Saving…' : 'Save Lead'}</button>
            <button className="btn btn-o" onClick={() => setShowAdd(false)}>Cancel</button>
          </div>
        </div>
      )}

      <div className="card">
        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px', color: 'var(--muted)' }}><span className="spinner" /></div>
        ) : leads.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px', color: 'var(--muted)', fontSize: 13 }}>
            No leads found. {search ? 'Try a different search.' : 'Add your first lead above!'}
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Lead</th><th>Contact</th><th>Interest</th><th>Source</th>
                <th>Score</th><th>Status</th><th>Added</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((l, i) => (
                <tr key={l.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 30, height: 30, borderRadius: '50%', background: AVATARS[i % 6], display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
                        {(l.name || '?')[0].toUpperCase()}
                      </div>
                      <span className="tn">{l.name}</span>
                    </div>
                  </td>
                  <td className="te">{l.phone}</td>
                  <td>{l.interest || l.locality || '—'}</td>
                  <td><span className={`badge ${SOURCE_COLORS[l.source] || 'bnew'}`}>{l.source || 'manual'}</span></td>
                  <td>
                    <span style={{ fontFamily: 'Syne,sans-serif', fontWeight: 800, fontSize: 13, color: (l.score || 50) >= 75 ? 'var(--green)' : (l.score || 50) >= 50 ? 'var(--amber)' : 'var(--red)' }}>
                      {l.score || 50}
                    </span>
                  </td>
                  <td>
                    <select
                      className={`badge ${STATUS_COLORS[l.status] || 'bnew'}`}
                      value={l.status || 'new'}
                      onChange={e => updateStatus(l.id, e.target.value)}
                      style={{ border: 'none', cursor: 'pointer', background: 'transparent', fontWeight: 700, fontSize: 10 }}>
                      <option value="new">New</option>
                      <option value="contacted">Contacted</option>
                      <option value="converted">Converted ✅</option>
                      <option value="lost">Lost</option>
                    </select>
                  </td>
                  <td className="te">{daysSince(l.created_at)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 5 }}>
                      <button className="btn btn-g btn-sm">📞</button>
                      <button className="btn btn-g btn-sm">💬</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
