// AdminUsers.jsx
import { useState, useEffect } from 'react';
import { adminAPI } from '../../api';

export default function AdminUsers() {
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminAPI.businesses().then(r => { setBusinesses(r.businesses || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const DEMO = [
    { id: 1, name: 'RisingRoof Properties', plan: 'growth', status: 'active', users: [{ name: 'Prakash', email: 'prakash@risingroof.in' }], created_at: '2025-10-01' },
    { id: 2, name: 'Grand Hotel Hyderabad', plan: 'growth', status: 'active', users: [{ name: 'Rajesh', email: 'rajesh@grandhotel.in' }], created_at: '2025-11-15' },
    { id: 3, name: 'Hotel Rihan', plan: 'starter', status: 'active', users: [{ name: 'Rihan', email: 'rihan@hotelrihan.in' }], created_at: '2026-01-10' },
    { id: 4, name: 'John Joe Realty', plan: 'starter', status: 'inactive', users: [{ name: 'John', email: 'john@johnjoe.in' }], created_at: '2026-02-20' },
  ];
  const display = businesses.length > 0 ? businesses : DEMO;

  const PLAN_BADGE = { growth: 'bactive', starter: 'bgoogle', pro: 'bowner', enterprise: 'badmin', trial: 'bnew' };
  const PLAN_PRICE = { growth: '₹2,999', starter: '₹999', pro: '₹7,999', enterprise: '₹24,999', trial: 'Free' };

  return (
    <div className="page-anim">
      <div className="ph"><h2>👤 All Users & Businesses</h2><p>{display.length} businesses on the platform</p></div>
      <div className="card">
        {loading ? <div style={{ textAlign: 'center', padding: 40 }}><span className="spinner" /></div> : (
          <table>
            <thead><tr><th>Business</th><th>Owner</th><th>Email</th><th>Plan</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
              {display.map(b => (
                <tr key={b.id}>
                  <td><div className="tn">{b.name}</div></td>
                  <td>{b.users?.[0]?.name || '—'}</td>
                  <td className="te">{b.users?.[0]?.email || '—'}</td>
                  <td>
                    <div>
                      <span className={`badge ${PLAN_BADGE[b.plan] || 'bnew'}`}>{b.plan}</span>
                      <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 2 }}>{PLAN_PRICE[b.plan] || '—'}/mo</div>
                    </div>
                  </td>
                  <td><span className={`badge ${b.status === 'active' ? 'bactive' : 'binactive'}`}>{b.status}</span></td>
                  <td className="te">{new Date(b.created_at).toLocaleDateString('en-IN')}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 5 }}>
                      <button className="btn btn-o btn-sm">View</button>
                      <button className="btn btn-a btn-sm">Edit Plan</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
