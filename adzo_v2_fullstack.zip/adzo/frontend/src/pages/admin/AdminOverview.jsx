import { useState, useEffect } from 'react';
import { adminAPI } from '../../api';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Tooltip, Legend, Filler } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Tooltip, Legend, Filler);

const baseOpts = () => ({
  responsive: true, maintainAspectRatio: true,
  plugins: { legend: { display: false }, tooltip: { backgroundColor: 'rgba(26,29,46,0.92)', padding: 10, cornerRadius: 8 } },
  scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { size: 10 }, color: '#9ca3af' } }, x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#9ca3af' } } },
});

export default function AdminOverview() {
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminAPI.overview().then(setOverview).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const revenueData = {
    labels: ['Oct','Nov','Dec','Jan','Feb','Mar','Apr*','May*'],
    datasets: [
      { label: 'MRR (₹K)', data: [4,6,8,12,15,18,22,27], borderColor: '#7c5cfc', backgroundColor: 'rgba(124,92,252,0.15)', fill: true, tension: 0.45, pointRadius: 4, borderWidth: 2.5 },
      { label: 'Target', data: [8,10,13,17,22,28,35,44], borderColor: 'rgba(5,150,105,0.5)', backgroundColor: 'transparent', borderDash: [5,4], tension: 0.3, pointRadius: 0, borderWidth: 1.5 },
    ],
  };

  const clientsData = {
    labels: ['Oct','Nov','Dec','Jan','Feb','Mar'],
    datasets: [{ data: [1,0,1,1,2,3], backgroundColor: ['rgba(124,92,252,.2)','rgba(124,92,252,.2)','rgba(124,92,252,.2)','rgba(124,92,252,.3)','rgba(124,92,252,.6)','#7c5cfc'], borderRadius: 6, borderSkipped: false }],
  };

  const planMixData = {
    labels: ['Starter ₹999 (×2)','Growth ₹2,999 (×3)','Pro ₹7,999 (×0)'],
    datasets: [{ data: [1998,8997,0], backgroundColor: ['#0284c7','#7c5cfc','rgba(217,119,6,0.7)'], borderWidth: 3, borderColor: '#fff', hoverOffset: 8 }],
  };

  const perClientData = {
    labels: ['RisingRoof','Grand Hotel','Hotel Rihan','John Joe'],
    datasets: [{ data: [147,89,34,0], backgroundColor: ['#7c5cfc','#059669','#0284c7','rgba(220,38,38,0.5)'], borderRadius: 5, borderSkipped: false }],
  };

  return (
    <div className="page-anim">
      <div className="ph"><h2>📊 Platform Overview</h2><p>All clients, all revenue, all leads in one view</p></div>

      <div className="sg4" style={{ marginBottom: 18 }}>
        <div className="sc p"><div className="slbl">Total Revenue (MRR)</div><div className="sval">₹{loading ? '…' : (overview?.mrr || 18000).toLocaleString('en-IN')}</div><div className="schg up">↑ Target: ₹1Cr/year</div><div className="sico">💰</div></div>
        <div className="sc g"><div className="slbl">Active Businesses</div><div className="sval">{loading ? '…' : overview?.active_businesses || 5}</div><div className="schg up">↑ +3 vs last month</div><div className="sico">🏢</div></div>
        <div className="sc b"><div className="slbl">Total Leads (All Clients)</div><div className="sval">{loading ? '…' : overview?.total_leads || 342}</div><div className="schg up">↑ +48 this week</div><div className="sico">🎯</div></div>
        <div className="sc a"><div className="slbl">ARR Projection</div><div className="sval">₹{loading ? '…' : ((overview?.mrr || 18000) * 12 / 100000).toFixed(1)}L</div><div className="schg nt">At current growth</div><div className="sico">📈</div></div>
      </div>

      <div className="adm-chart-grid">
        <div className="chart-card">
          <div className="chart-title">📈 Monthly Revenue — Path to ₹1Cr</div>
          <div className="chart-sub">MRR vs your ₹1Cr/year target</div>
          <Line data={revenueData} options={{ ...baseOpts(), plugins: { legend: { display: true, position: 'top', labels: { font: { size: 10 }, boxWidth: 10, color: '#6b7280' } }, tooltip: { backgroundColor: 'rgba(26,29,46,0.92)' } } }} />
          <div className="insight-box">💡 At current growth you'll hit <strong>₹1Cr ARR by Q3 2027</strong>. Adding 5 Pro-plan clients this quarter accelerates this by 6 months.</div>
        </div>
        <div className="chart-card">
          <div className="chart-title">🏢 Client Growth</div>
          <div className="chart-sub">New businesses onboarded each month</div>
          <Bar data={clientsData} options={baseOpts()} />
          <div className="insight-box">💡 March is your best month — 3 new clients! Focus on referrals from existing happy clients.</div>
        </div>
      </div>

      <div className="adm-chart-grid">
        <div className="chart-card">
          <div className="chart-title">🍩 Revenue Split by Plan</div>
          <div className="chart-sub">Which plan earns you the most</div>
          <Doughnut data={planMixData} options={{ ...baseOpts(), cutout: '64%', plugins: { legend: { display: true, position: 'right', labels: { font: { size: 10 }, boxWidth: 11, color: '#6b7280' } }, tooltip: { backgroundColor: 'rgba(26,29,46,0.92)' } } }} />
          <div className="insight-box">💡 Upselling 2 clients to Pro (₹7,999) would add <strong>₹10K/month instantly</strong>.</div>
        </div>
        <div className="chart-card">
          <div className="chart-title">📊 Leads per Client — This Month</div>
          <div className="chart-sub">Which client is most active</div>
          <Bar data={perClientData} options={{ ...baseOpts(), indexAxis: 'y', scales: { x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { font: { size: 10 }, color: '#9ca3af' } }, y: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#6b7280' } } } }} />
          <div className="insight-box">💡 John Joe has 0 leads — likely inactive. Schedule a check-in call to prevent churn.</div>
        </div>
      </div>
    </div>
  );
}
