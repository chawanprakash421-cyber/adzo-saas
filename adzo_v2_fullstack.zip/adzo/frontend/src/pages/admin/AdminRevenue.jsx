import { useEffect, useState } from 'react';
import { adminAPI } from '../../api';

export default function AdminRevenue() {
  const [data, setData] = useState(null);
  useEffect(() => { adminAPI.revenue().then(setData).catch(() => {}); }, []);

  const DEMO_TXN = [
    { id: 1, business_id: 'RisingRoof', amount: 2999, description: 'Growth Plan renewal', created_at: '2026-03-01' },
    { id: 2, business_id: 'Grand Hotel', amount: 2999, description: 'Growth Plan renewal', created_at: '2026-03-05' },
    { id: 3, business_id: 'Hotel Rihan', amount: 999, description: 'Starter Plan renewal', created_at: '2026-03-10' },
    { id: 4, business_id: 'RisingRoof', amount: 1000, description: 'Wallet top-up', created_at: '2026-03-12' },
  ];

  const txns = data?.transactions?.length > 0 ? data.transactions : DEMO_TXN;
  const total = txns.reduce((s, t) => s + (t.amount || 0), 0);

  return (
    <div className="page-anim">
      <div className="ph"><h2>💰 Revenue</h2><p>All payments and subscription revenue</p></div>
      <div className="sg3" style={{ marginBottom: 18 }}>
        <div className="sc p"><div className="slbl">Total Revenue</div><div className="sval">₹{total.toLocaleString('en-IN')}</div><div className="schg up">All time</div></div>
        <div className="sc g"><div className="slbl">MRR</div><div className="sval">₹18K</div><div className="schg up">↑ +₹3K vs last month</div></div>
        <div className="sc b"><div className="slbl">ARR Projection</div><div className="sval">₹2.16L</div><div className="schg nt">At current growth</div></div>
      </div>
      <div className="card">
        <div className="card-hd"><div className="card-title">All Transactions</div></div>
        <table>
          <thead><tr><th>Business</th><th>Description</th><th>Amount</th><th>Date</th></tr></thead>
          <tbody>
            {txns.map((t, i) => (
              <tr key={i}>
                <td className="tn">{t.business_id}</td>
                <td>{t.description}</td>
                <td style={{ color: 'var(--green)', fontWeight: 700 }}>+₹{(t.amount || 0).toLocaleString('en-IN')}</td>
                <td className="te">{new Date(t.created_at).toLocaleDateString('en-IN')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
