export { Support as default } from './OtherPages';
