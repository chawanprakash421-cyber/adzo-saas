export { Listings as default } from './OtherPages';
