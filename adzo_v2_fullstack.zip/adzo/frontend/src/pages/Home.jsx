import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { leadsAPI, contentAPI } from '../api';
import { useAuth } from '../contexts/AuthContext';

const FOLLOWUP_AVATARS = ['#7c5cfc', '#f59e0b', '#38bdf8', '#34d399', '#f97316'];

export default function Home() {
  const { user, business } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [followups, setFollowups] = useState([]);
  const [priyaInput, setPriyaInput] = useState('');
  const [priyaReply, setPriyaReply] = useState('');
  const [priyaLoading, setPriyaLoading] = useState(false);

  useEffect(() => {
    leadsAPI.stats().then(setStats).catch(() => {});
    leadsAPI.followup().then(r => setFollowups(r.leads?.slice(0, 3) || [])).catch(() => {});
  }, []);

  const askPriya = async () => {
    if (!priyaInput.trim()) return;
    setPriyaLoading(true);
    try {
      const { reply } = await contentAPI.priya(priyaInput, []);
      setPriyaReply(reply);
    } catch { setPriyaReply("I'm having a moment — please try again 🙏"); }
    finally { setPriyaLoading(false); }
  };

  const daysSince = (dateStr) => {
    if (!dateStr) return '?';
    const d = Math.floor((Date.now() - new Date(dateStr)) / 86400000);
    return d === 0 ? 'Today' : `${d} day${d > 1 ? 's' : ''} ago`;
  };

  return (
    <div className="page-anim">
      {/* Wallet alert */}
      <div className="alert-bar">
        ⚠ Your wallet balance is running low.
        <a onClick={() => navigate('/wallet')}>Top Up Now →</a>
      </div>

      {/* Priya AI Card */}
      <div className="zoya-card">
        <div className="zoya-header">
          <div className="zoya-avatar">🤖</div>
          <div>
            <div className="zoya-name">Priya · Your AI Business Manager</div>
            <div className="zoya-role"><span className="zoya-pulse" />Online now · Hyderabad Real Estate Expert</div>
          </div>
        </div>
        <div className="zoya-msg">
          <span className="hi">Good morning, {user?.name?.split(' ')[0] || 'there'}! 👋</span>
          You got <strong>{stats?.new_today || 0} new leads</strong> today.{' '}
          <strong>{stats?.followup_needed || 0} follow-up calls</strong> are due. Your ads are running well! 🎉
          {priyaReply && <div style={{ marginTop: 10, background: 'rgba(255,255,255,.12)', borderRadius: 8, padding: '10px 12px', fontSize: 12 }}><strong>Priya:</strong> {priyaReply}</div>}
        </div>
        <div className="zoya-chips">
          <div className="zchip urgent" onClick={() => navigate('/followup')}>📞 {stats?.followup_needed || 0} follow-ups pending</div>
          <div className="zchip urgent">💬 Check WhatsApp replies</div>
          <div className="zchip good">✅ {stats?.new_today || 0} leads today!</div>
          <div className="zchip">📅 Ugadi Campaign</div>
        </div>
        <div className="zoya-input-row">
          <input
            className="zoya-input"
            placeholder="Ask Priya anything… 'Write a WhatsApp for Vinay' or 'How are my ads?'"
            value={priyaInput}
            onChange={e => setPriyaInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && askPriya()}
          />
          <button className="zbtn" onClick={askPriya} disabled={priyaLoading}>
            {priyaLoading ? '…' : 'Ask Priya ✨'}
          </button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="sg4">
        <div className="sc p">
          <div className="slbl">People Enquired</div>
          <div className="sval">{stats?.total ?? '—'}</div>
          <div className="schg up">↑ {stats?.new_today || 0} new today</div>
          <div className="simple-explain">Total people who asked about your property</div>
          <div className="sico">🎯</div>
        </div>
        <div className="sc g">
          <div className="slbl">Deals Closed</div>
          <div className="sval">{stats?.converted ?? '—'}</div>
          <div className="schg up">People who bought / booked</div>
          <div className="simple-explain">Your confirmed bookings</div>
          <div className="sico">🏆</div>
        </div>
        <div className="sc b">
          <div className="slbl">Ad Money Spent</div>
          <div className="sval">₹26.4K</div>
          <div className="schg nt">This month</div>
          <div className="simple-explain">Each lead cost you just ₹182</div>
          <div className="sico">💰</div>
        </div>
        <div className="sc a">
          <div className="slbl">Wallet Balance</div>
          <div className="sval">₹4,250</div>
          <div className="schg dn">⚠ 6 days left</div>
          <div className="simple-explain">Add money to keep ads running</div>
          <div className="sico">💳</div>
        </div>
      </div>

      <div className="g32">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Action Center */}
          <div className="action-card">
            <div className="action-title">🎯 Do These 3 Things Right Now</div>
            {[
              { icon: '📞', bg: 'var(--red-bg)', title: 'Call your hottest lead — waiting 2 hours!', desc: 'Enquired about 2BHK in Gachibowli. Score: 92/100', priority: 'URGENT', p: 'ap-high', btn: '📞 Call', path: '/leads' },
              { icon: '💬', bg: 'var(--amber-bg)', title: 'Reply to 3 WhatsApp messages', desc: 'Leads are waiting. Avg wait: 4 hours', priority: 'TODAY', p: 'ap-med', btn: 'Reply', path: '/leads' },
              { icon: '💳', bg: 'var(--accent-glow)', title: 'Top up your wallet before Friday', desc: 'Campaigns pause automatically if balance hits ₹0', priority: 'SOON', p: 'ap-med', btn: 'Top Up', path: '/wallet' },
            ].map((a, i) => (
              <div className="action-item" key={i}>
                <div className="aico" style={{ background: a.bg }}>{a.icon}</div>
                <div className="atext">
                  <div className="atitle">{a.title}</div>
                  <div className="adesc">{a.desc}</div>
                </div>
                <span className={`apriority ${a.p}`}>{a.priority}</span>
                <button className="btn btn-g btn-sm" onClick={() => navigate(a.path)}>{a.btn}</button>
              </div>
            ))}
          </div>

          {/* Follow-up Reminders */}
          <div className="card">
            <div className="card-hd">
              <div className="card-title">⏰ Follow-up Reminders</div>
              <button className="card-act" onClick={() => navigate('/followup')}>See All →</button>
            </div>
            <div className="section-intro">These leads have not been contacted in a while. <strong>Call or WhatsApp them today</strong> before they go to a competitor.</div>
            {followups.length === 0 && <div style={{ fontSize: 12, color: 'var(--muted)', textAlign: 'center', padding: '20px 0' }}>✅ All caught up! No follow-ups needed right now.</div>}
            {followups.map((lead, i) => (
              <div className="fu-item" key={lead.id}>
                <div className="fu-ava" style={{ background: FOLLOWUP_AVATARS[i % 5] }}>
                  {(lead.name || '?')[0].toUpperCase()}
                </div>
                <div className="fu-info">
                  <div className="fu-name">{lead.name}</div>
                  <div className="fu-meta">{lead.interest || 'Property enquiry'} · {lead.source || 'Direct'}</div>
                </div>
                <div className="fu-since" style={{ color: i === 0 ? 'var(--red)' : 'var(--amber)' }}>{daysSince(lead.last_contact)}</div>
                <div className="fu-actions">
                  <button className="btn btn-g btn-sm">📞</button>
                  <button className="btn btn-g btn-sm">💬</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Health Score */}
          <div className="health-card">
            <div className="card-hd"><div className="card-title">🏆 Business Health Score</div></div>
            <div className="section-intro" style={{ fontSize: 10, marginBottom: 10 }}>How well your business is growing this month on a scale of 0–100</div>
            <div className="health-ring">
              <svg width="90" height="90" viewBox="0 0 90 90">
                <circle cx="45" cy="45" r="36" fill="none" stroke="rgba(0,0,0,0.08)" strokeWidth="8" />
                <circle cx="45" cy="45" r="36" fill="none" stroke="#22d3a0" strokeWidth="8" strokeDasharray="226" strokeDashoffset="45" strokeLinecap="round" />
              </svg>
              <div className="health-num" style={{ color: 'var(--green)' }}>80</div>
            </div>
            <div className="health-label" style={{ color: 'var(--green)' }}>Very Good 🎉</div>
            {[
              { label: 'Leads coming in', pct: 90, color: 'var(--green)' },
              { label: 'Following up', pct: 55, color: 'var(--amber)' },
              { label: 'Content posted', pct: 80, color: 'var(--accent)' },
              { label: 'Reviews got', pct: 70, color: 'var(--blue)' },
            ].map(r => (
              <div className="health-bar-row" key={r.label}>
                <span className="hbr-label">{r.label}</span>
                <div className="hbr-bar"><div className="hbr-fill" style={{ width: r.pct + '%', background: r.color }} /></div>
                <span className="hbr-score" style={{ color: r.color }}>{r.pct}</span>
              </div>
            ))}
            <div className="tip-box">📌 Tip: Your follow-up score is low. Call {stats?.followup_needed || 7} pending leads today to reach 90+ score!</div>
          </div>

          {/* Wallet */}
          <div className="wallet-glow">
            <div className="wlbl">💳 Wallet Balance</div>
            <div className="wamt">₹4,250</div>
            <div className="wsub">⚠ Runs out in ~6 days</div>
            <button className="btn btn-p" style={{ width: '100%', justifyContent: 'center', marginTop: 12 }} onClick={() => navigate('/wallet')}>Add Money →</button>
          </div>

          {/* Leaderboard */}
          <div className="leaderboard-card">
            <div className="lb-header">
              <div className="lb-title">🏆 Neighbourhood Leaderboard</div>
              <div className="lb-locality">📍 Kondapur Area</div>
            </div>
            {[
              { rank: '🥇', name: 'Urbanrise Properties', score: 94, color: '#f59e0b', cls: 'r1' },
              { rank: '2', name: business?.name || 'Your Business', score: 80, color: 'var(--accent)', cls: 'ryou', you: true },
              { rank: '3', name: 'Prestige Channel Partner', score: 71, color: '#b45309', cls: 'r3' },
              { rank: '4', name: 'Square Yards Hyderabad', score: 58, color: 'var(--muted)', cls: '' },
            ].map((r, i) => (
              <div className={`lb-row${r.you ? ' you' : ''}`} key={i}>
                <div className={`lb-rank ${r.cls}`}>{r.rank}</div>
                <div className="lb-name">{r.name}{r.you && <span className="lb-you-tag">YOU</span>}</div>
                <div className="lb-score-wrap">
                  <div className="lb-score" style={{ color: r.color }}>{r.score}</div>
                  <div className="lb-bar"><div className="lb-fill" style={{ width: r.score + '%', background: r.color }} /></div>
                </div>
              </div>
            ))}
            <div className="lb-tip">💡 You're <strong>#2 in Kondapur</strong>! Post 3 more property reels + get 5 Google reviews to reach #1. 🚀</div>
          </div>
        </div>
      </div>
    </div>
  );
}
