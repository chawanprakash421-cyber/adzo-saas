import { useEffect, useRef, useState } from 'react';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement,
  BarElement, ArcElement, Tooltip, Legend, Filler,
} from 'chart.js';
import { Line, Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Tooltip, Legend, Filler);

const baseOpts = (extra = {}) => ({
  responsive: true, maintainAspectRatio: true,
  plugins: { legend: { display: false }, tooltip: { backgroundColor: 'rgba(26,29,46,0.92)', padding: 10, cornerRadius: 8 } },
  scales: {
    y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { size: 10 }, color: '#9ca3af' } },
    x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#9ca3af' } },
  },
  ...extra,
});

export default function Analytics() {
  const [period, setPeriod] = useState('30d');

  const leadsData = {
    labels: ['Mar 1','Mar 5','Mar 10','Mar 15','Mar 20','Mar 25','Mar 30'],
    datasets: [{ label: 'Leads', data: [4,7,5,9,12,8,14], borderColor: '#7c5cfc', backgroundColor: 'rgba(124,92,252,0.12)', fill: true, tension: 0.45, pointRadius: 4, borderWidth: 2.5 }],
  };

  const sourcesData = {
    labels: ['Google Ads', 'Meta Ads', 'WhatsApp', 'Organic'],
    datasets: [{ data: [72, 48, 18, 9], backgroundColor: ['#0284c7','#818cf8','#059669','#f97316'], borderWidth: 3, borderColor: '#fff', hoverOffset: 8 }],
  };

  const dealsData = {
    labels: ['Oct','Nov','Dec','Jan','Feb','Mar'],
    datasets: [{ label: 'Deals', data: [2, 3, 2, 4, 5, 8], backgroundColor: '#7c5cfc', borderRadius: 6, borderSkipped: false }],
  };

  const spendLeadsData = {
    labels: ['Oct','Nov','Dec','Jan','Feb','Mar'],
    datasets: [
      { label: 'Ad Spend (₹K)', data: [12, 15, 14, 18, 22, 26], borderColor: '#0284c7', backgroundColor: 'transparent', tension: 0.4, yAxisID: 'y' },
      { label: 'Leads', data: [38, 51, 49, 71, 88, 147], borderColor: '#7c5cfc', backgroundColor: 'transparent', tension: 0.4, yAxisID: 'y1' },
    ],
  };

  const funnelData = {
    labels: ['Ad Clicks', 'Form Fills', 'Qualified', 'Site Visit', 'Deal Closed'],
    datasets: [{ data: [342, 147, 89, 31, 18], backgroundColor: ['rgba(124,92,252,.8)','rgba(124,92,252,.65)','rgba(124,92,252,.5)','rgba(124,92,252,.35)','rgba(5,150,105,.8)'], borderRadius: 5 }],
  };

  const qualityData = {
    labels: ['Hot (80+)', 'Warm (50-80)', 'Cold (<50)'],
    datasets: [{ data: [34, 72, 41], backgroundColor: ['#059669','#d97706','#9ca3af'], borderWidth: 3, borderColor: '#fff' }],
  };

  return (
    <div className="page-anim">
      <div className="ph"><h2>📊 Analytics & Charts</h2><p>Your complete business performance — no jargon</p></div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
        <div style={{ fontSize: 12, color: 'var(--muted)' }}>Showing data for:</div>
        <div className="period-tabs">
          {[['7d','7 Days'],['30d','30 Days'],['90d','3 Months']].map(([k,l]) => (
            <button key={k} className={`period-tab${period === k ? ' active' : ''}`} onClick={() => setPeriod(k)}>{l}</button>
          ))}
        </div>
      </div>

      <div className="sg4" style={{ marginBottom: 18 }}>
        <div className="sc p"><div className="slbl">Total Leads</div><div className="sval">147</div><div className="schg up">↑ +24% vs last month</div><div className="simple-explain">People who enquired</div></div>
        <div className="sc g"><div className="slbl">Deals Closed</div><div className="sval">18</div><div className="schg up">↑ +3 this month</div><div className="simple-explain">People who bought</div></div>
        <div className="sc b"><div className="slbl">Ad Spend</div><div className="sval">₹26.4K</div><div className="schg nt">This month</div><div className="simple-explain">Total ads money</div></div>
        <div className="sc a"><div className="slbl">Revenue</div><div className="sval">₹1.1Cr</div><div className="schg up">↑ Estimated</div><div className="simple-explain">Closed deals value</div></div>
      </div>

      <div className="analytics-grid">
        <div className="chart-card">
          <div className="chart-title">📈 Daily Leads — This Month</div>
          <div className="chart-sub">How many new people enquired each day</div>
          <Line data={leadsData} options={baseOpts()} />
          <div className="insight-box">💡 <strong>Priya's Insight:</strong> Your leads peak on Tuesdays & Fridays. Schedule follow-ups on those days for best results.</div>
        </div>
        <div className="chart-card">
          <div className="chart-title">🍩 Where Your Leads Come From</div>
          <div className="chart-sub">Which platform brings you the most enquiries</div>
          <Doughnut data={sourcesData} options={{ ...baseOpts(), cutout: '64%', plugins: { legend: { display: true, position: 'right', labels: { font: { size: 10 }, boxWidth: 11, padding: 10, color: '#6b7280' } }, tooltip: { backgroundColor: 'rgba(26,29,46,0.92)' } } }} />
          <div className="insight-box">💡 Google Ads is your #1 source — 49% of all leads. Consider increasing that budget by ₹200/day.</div>
        </div>
      </div>

      <div className="analytics-grid">
        <div className="chart-card">
          <div className="chart-title">🏆 Deals Closed — Last 6 Months</div>
          <div className="chart-sub">Number of bookings every month</div>
          <Bar data={dealsData} options={baseOpts()} />
          <div className="insight-box">💡 March is your best month ever! You have 8 hot leads right now that could convert this month.</div>
        </div>
        <div className="chart-card">
          <div className="chart-title">💰 Ad Spend vs Leads Generated</div>
          <div className="chart-sub">Are you getting value for every rupee spent?</div>
          <Line data={spendLeadsData} options={baseOpts({ plugins: { legend: { display: true, position: 'top', labels: { font: { size: 10 }, boxWidth: 10, color: '#6b7280' } }, tooltip: { backgroundColor: 'rgba(26,29,46,0.92)' } }, scales: { y: { beginAtZero: true, position: 'left', grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { size: 10 }, color: '#9ca3af' } }, y1: { beginAtZero: true, position: 'right', grid: { display: false }, ticks: { font: { size: 10 }, color: '#9ca3af' } }, x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#9ca3af' } } } })} />
          <div className="insight-box">💡 Your cost per lead dropped from ₹216 → ₹182. That's a 16% improvement — your campaigns are getting smarter!</div>
        </div>
      </div>

      <div className="chart-card chart-full">
        <div className="chart-title">🔽 Your Full Lead Funnel</div>
        <div className="chart-sub">Where people drop off — and where you can win more</div>
        <Bar data={funnelData} options={baseOpts()} />
        <div className="insight-box">
          💡 89 leads clicked your ad but never booked a site visit. That's your biggest opportunity.{' '}
          <button className="btn btn-p btn-sm" style={{ marginLeft: 10 }}>Launch Re-engagement →</button>
        </div>
      </div>

      <div className="analytics-grid" style={{ gridTemplateColumns: '1fr 2fr' }}>
        <div className="chart-card">
          <div className="chart-title">⚡ Lead Quality</div>
          <div className="chart-sub">Hot, warm, and cold leads</div>
          <Doughnut data={qualityData} options={{ ...baseOpts(), cutout: '60%', plugins: { legend: { display: true, position: 'bottom', labels: { font: { size: 10 }, boxWidth: 10, color: '#6b7280' } }, tooltip: { backgroundColor: 'rgba(26,29,46,0.92)' } } }} />
        </div>
        <div className="chart-card">
          <div className="chart-title">⭐ Review Growth</div>
          <div className="chart-sub">Google & social reviews over time</div>
          <Line data={{ labels: ['Oct','Nov','Dec','Jan','Feb','Mar'], datasets: [{ label: 'Reviews', data: [12,18,22,28,31,47], borderColor: '#d97706', backgroundColor: 'rgba(217,119,6,0.1)', fill: true, tension: 0.4 }] }} options={baseOpts()} />
          <div className="insight-box">You've got <strong>47 reviews</strong> this month — up from 31. Ask Priya to send review requests to recent buyers.</div>
        </div>
      </div>
    </div>
  );
}
