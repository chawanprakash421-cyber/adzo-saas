import { useState, useEffect } from 'react';
import { walletAPI } from '../api';

const PLANS = [
  { id: 'starter', name: 'Starter', price: 999, popular: false, features: ['50 leads/month','WhatsApp auto-reply','1 campaign','Basic reports'] },
  { id: 'growth', name: 'Growth', price: 2999, popular: true, features: ['200 leads/month','AI content generation','3 campaigns','Follow-up automation','Priority support'] },
  { id: 'pro', name: 'Pro', price: 7999, popular: false, features: ['Unlimited leads','Full AI content suite','Unlimited campaigns','Advanced analytics','Competitor watch','Dedicated manager'] },
  { id: 'enterprise', name: 'Enterprise', price: 24999, popular: false, features: ['Everything in Pro','Custom integrations','White-label option','API access','SLA guarantee'] },
];

const TOPUP_AMOUNTS = [500, 1000, 2000, 5000];

export default function Wallet() {
  const [wallet, setWallet] = useState(null);
  const [txns, setTxns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [amount, setAmount] = useState(1000);
  const [paying, setPaying] = useState(false);

  useEffect(() => {
    walletAPI.get()
      .then(({ wallet, transactions }) => { setWallet(wallet); setTxns(transactions); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const topup = async () => {
    setPaying(true);
    try {
      const { order, key } = await walletAPI.createOrder(amount);
      const options = {
        key,
        amount: order.amount,
        currency: 'INR',
        name: 'Adzo',
        description: 'Wallet Top-up',
        order_id: order.id,
        handler: async function (response) {
          const res = await walletAPI.verify({ ...response, amount });
          if (res.success) {
            setWallet(w => ({ ...w, balance: res.newBalance }));
            setTxns(t => [{ id: Date.now(), type: 'credit', amount, description: 'Wallet top-up', created_at: new Date().toISOString() }, ...t]);
            alert('✅ Wallet topped up! New balance: ₹' + res.newBalance);
          }
        },
        theme: { color: '#7c5cfc' },
      };
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (e) {
      alert('Payment failed: ' + e.message);
    }
    setPaying(false);
  };

  return (
    <div className="page-anim">
      <div className="ph"><h2>💳 Wallet & Plans</h2><p>Manage your ad budget and subscription</p></div>

      <div className="g21" style={{ marginBottom: 20 }}>
        {/* Wallet card */}
        <div className="wallet-glow">
          <div className="wlbl">💳 Current Wallet Balance</div>
          <div className="wamt">₹{loading ? '…' : (wallet?.balance || 0).toLocaleString('en-IN')}</div>
          <div className="wsub">
            {(wallet?.balance || 0) < 1000 ? '⚠ Running low — top up to keep ads running' : '✅ Good — ads are running'}
          </div>

          <div style={{ marginTop: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--accent)', marginBottom: 8 }}>Quick Top-up</div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
              {TOPUP_AMOUNTS.map(a => (
                <button key={a} className={`btn btn-sm ${amount === a ? 'btn-p' : 'btn-o'}`} onClick={() => setAmount(a)}>₹{a.toLocaleString('en-IN')}</button>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                style={{ flex: 1, border: '1px solid rgba(124,92,252,.3)', borderRadius: 'var(--rsm)', padding: '8px 12px', fontSize: 13, background: 'rgba(255,255,255,.5)' }}
                type="number" min="100" value={amount}
                onChange={e => setAmount(Number(e.target.value))}
                placeholder="Custom amount"
              />
              <button className="btn btn-p" onClick={topup} disabled={paying || amount < 100}>
                {paying ? 'Opening…' : `Pay ₹${amount.toLocaleString('en-IN')} →`}
              </button>
            </div>
            <div style={{ fontSize: 10, color: '#5b5f7a', marginTop: 6 }}>Secured by Razorpay · UPI, cards, netbanking accepted</div>
          </div>
        </div>

        {/* Transaction history */}
        <div className="card">
          <div className="card-hd"><div className="card-title">📋 Transaction History</div></div>
          {txns.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '20px', color: 'var(--muted)', fontSize: 12 }}>No transactions yet</div>
          ) : (
            <table>
              <thead><tr><th>Description</th><th>Amount</th><th>Date</th></tr></thead>
              <tbody>
                {txns.map(t => (
                  <tr key={t.id}>
                    <td>{t.description}</td>
                    <td style={{ color: t.type === 'credit' ? 'var(--green)' : 'var(--red)', fontWeight: 700 }}>
                      {t.type === 'credit' ? '+' : '-'}₹{t.amount?.toLocaleString('en-IN')}
                    </td>
                    <td className="te">{new Date(t.created_at).toLocaleDateString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Plans */}
      <div className="ph" style={{ marginBottom: 16 }}>
        <h2 style={{ fontSize: 17 }}>📦 Subscription Plans</h2>
        <p>Choose a plan that fits your business size</p>
      </div>
      <div className="plans-grid">
        {PLANS.map(plan => (
          <div key={plan.id} className={`plan-card${plan.popular ? ' popular' : ''}`}>
            {plan.popular && (
              <div style={{ background: 'var(--accent)', color: '#fff', fontSize: 9, fontWeight: 700, padding: '3px 10px', borderRadius: 20, display: 'inline-block', marginBottom: 8, letterSpacing: 1 }}>
                MOST POPULAR
              </div>
            )}
            <div className="plan-name">{plan.name}</div>
            <div className="plan-price">₹{plan.price.toLocaleString('en-IN')}<span>/month</span></div>
            <div style={{ borderTop: '1px solid var(--border)', margin: '12px 0' }} />
            {plan.features.map(f => (
              <div className="plan-feature" key={f}>{f}</div>
            ))}
            <button className={`btn ${plan.popular ? 'btn-p' : 'btn-o'}`} style={{ width: '100%', justifyContent: 'center', marginTop: 14 }}>
              {plan.popular ? 'Get Growth Plan →' : `Choose ${plan.name}`}
            </button>
          </div>
        ))}
      </div>

      {/* Load Razorpay script */}
      <script src="https://checkout.razorpay.com/v1/checkout.js" async />
    </div>
  );
}
