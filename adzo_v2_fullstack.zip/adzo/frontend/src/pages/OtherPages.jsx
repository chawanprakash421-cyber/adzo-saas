// FollowUp.jsx
import { useState, useEffect } from 'react';
import { leadsAPI } from '../api';

const AVATARS = ['#7c5cfc','#f59e0b','#38bdf8','#34d399','#f97316'];

export function FollowUp() {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    leadsAPI.followup().then(r => { setLeads(r.leads || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const daysSince = (d) => {
    if (!d) return 'Unknown';
    const n = Math.floor((Date.now() - new Date(d)) / 86400000);
    return n === 0 ? 'Today' : n === 1 ? '1 day ago' : `${n} days ago`;
  };

  const markContacted = async (id) => {
    await leadsAPI.update(id, { status: 'contacted', last_contact: new Date() });
    setLeads(ls => ls.filter(l => l.id !== id));
  };

  return (
    <div className="page-anim">
      <div className="ph"><h2>⏰ Follow-Up Needed</h2><p>These leads haven't been contacted in 24+ hours. Call or WhatsApp them today!</p></div>

      <div className="alert-bar">
        ⚡ Leads replied to within 30 minutes convert <strong>5x more</strong>. Enable Priya's auto-reply to fix your response time.
        <a>Enable Auto-Reply →</a>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40 }}><span className="spinner" /></div>
      ) : leads.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>✅</div>
          <div style={{ fontFamily: 'Syne,sans-serif', fontWeight: 800, fontSize: 16, marginBottom: 6 }}>All caught up!</div>
          <div style={{ color: 'var(--muted)', fontSize: 13 }}>You've contacted all your recent leads. Great work!</div>
        </div>
      ) : (
        <div className="card">
          {leads.map((lead, i) => (
            <div className="fu-item" key={lead.id} style={{ padding: '14px 0' }}>
              <div className="fu-ava" style={{ background: AVATARS[i % 5] }}>{(lead.name || '?')[0].toUpperCase()}</div>
              <div className="fu-info">
                <div className="fu-name">{lead.name}</div>
                <div className="fu-meta">
                  {lead.interest && <span>Interested in {lead.interest} · </span>}
                  {lead.locality && <span>📍 {lead.locality} · </span>}
                  {lead.budget && <span>Budget: {lead.budget} · </span>}
                  <span className="badge" style={{ background: 'rgba(2,132,199,.1)', color: 'var(--blue)', fontSize: 9 }}>{lead.source || 'direct'}</span>
                </div>
              </div>
              <div className="fu-since" style={{ color: i < 2 ? 'var(--red)' : 'var(--amber)', minWidth: 70, textAlign: 'right' }}>
                {daysSince(lead.last_contact)}
              </div>
              <div className="fu-actions">
                <button className="btn btn-g btn-sm">📞 Call</button>
                <button className="btn btn-g btn-sm">💬 WhatsApp</button>
                <button className="btn btn-o btn-sm" onClick={() => markContacted(lead.id)}>✓ Done</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Campaigns.jsx
import { useState, useEffect } from 'react';
import { campaignsAPI } from '../api';

export function Campaigns() {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    campaignsAPI.list().then(r => { setCampaigns(r.campaigns || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const DEMO = [
    { id: 1, name: 'Hyderabad Flat Buyers', platform: 'google', status: 'running', leads_count: 34, budget_daily: 850, spend: 18700, budget_total: 27000 },
    { id: 2, name: '2BHK Awareness Reel', platform: 'meta', status: 'running', leads_count: 28, budget_daily: 500, spend: 6750, budget_total: 15000 },
    { id: 3, name: 'Auto Follow-up Flow', platform: 'whatsapp', status: 'running', leads_count: 82, budget_daily: 0 },
  ];

  const display = campaigns.length > 0 ? campaigns : DEMO;
  const PBADGE = { google: 'bgoogle', meta: 'bmeta', whatsapp: 'bwa' };
  const PNAME = { google: 'Google Search', meta: 'Meta (FB+IG)', whatsapp: 'WhatsApp Auto' };

  return (
    <div className="page-anim">
      <div className="ph"><h2>📢 Campaigns</h2><p>Your active ad campaigns and automated flows</p></div>
      <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
        <button className="btn btn-p">+ Create Campaign</button>
        <button className="btn btn-o">🤖 Priya Suggest Campaign</button>
      </div>

      <div className="local-intel" style={{ marginBottom: 16 }}>
        <div className="local-intel-hd">
          <div className="card-title">📍 Hyderabad Market Pulse</div>
          <div className="locality-pill">🔄 Updated Today</div>
        </div>
        {[
          { loc: 'Gachibowli', trend: 'High IT buyer demand · 2&3 BHK most searched this week', badge: 'mhot', label: '🔥 Hot' },
          { loc: 'Financial Dist.', trend: 'Rising searches +28% · Ready-to-move preferred', badge: 'mrise', label: '↑ Rising' },
          { loc: 'Kondapur', trend: 'Steady demand · Budget buyers 60-85L segment active', badge: 'mstable', label: 'Stable' },
          { loc: 'Tellapur', trend: 'New launches driving interest · ORR connectivity big draw', badge: 'mrise', label: '↑ Rising' },
        ].map(r => (
          <div className="market-row" key={r.loc}>
            <div className="market-loc">{r.loc}</div>
            <div className="market-trend">{r.trend}</div>
            <div className={`market-badge ${r.badge}`}>{r.label}</div>
          </div>
        ))}
      </div>

      <div className="g31">
        {display.map(c => (
          <div className="camp-card" key={c.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <span className={`badge ${PBADGE[c.platform] || 'bnew'}`}>{PNAME[c.platform] || c.platform}</span>
              <span className="badge bactive">● {c.status}</span>
            </div>
            <div style={{ fontWeight: 700, marginBottom: 3 }}>{c.name}</div>
            <div className="sg2" style={{ gap: 8, margin: '10px 0' }}>
              <div style={{ background: 'var(--bg)', borderRadius: 8, padding: 10, textAlign: 'center' }}>
                <div style={{ fontSize: 20, fontWeight: 800, fontFamily: 'Syne,sans-serif', color: 'var(--green)' }}>{c.leads_count || 0}</div>
                <div style={{ fontSize: 9, color: 'var(--muted)' }}>People enquired</div>
              </div>
              <div style={{ background: 'var(--bg)', borderRadius: 8, padding: 10, textAlign: 'center' }}>
                <div style={{ fontSize: 20, fontWeight: 800, fontFamily: 'Syne,sans-serif' }}>{c.budget_daily ? `₹${c.budget_daily}` : 'Auto'}</div>
                <div style={{ fontSize: 9, color: 'var(--muted)' }}>Per day spend</div>
              </div>
            </div>
            {c.budget_total > 0 && <>
              <div className="pbar"><div className="pfill" style={{ width: Math.round((c.spend / c.budget_total) * 100) + '%', background: 'var(--blue)' }} /></div>
              <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 4 }}>₹{(c.spend||0).toLocaleString('en-IN')} of ₹{(c.budget_total||0).toLocaleString('en-IN')} budget used</div>
            </>}
            <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
              <button className="btn btn-o btn-sm">Edit</button>
              <button className="btn btn-r btn-sm">Pause</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Listings.jsx
export function Listings() {
  const listings = [
    { emoji: '🏢', price: '₹72L', name: 'Prestige Sky Vista — 2BHK', meta: 'Financial District · 1,250 sqft · Ready to move', leads: 42, visits: 8, status: 'Active' },
    { emoji: '🏘️', price: '₹55L', name: 'My Home Vihanga — 2BHK', meta: 'Tellapur · 1,150 sqft · Under Construction', leads: 28, visits: 5, status: 'Active' },
    { emoji: '🌟', price: '₹1.2Cr', name: 'Aparna Sarovar — 3BHK', meta: 'Nallagandla · 1,680 sqft · Ready to move', leads: 19, visits: 4, status: 'Active' },
    { emoji: '🏗️', price: '₹68L', name: 'Incor One City — 2BHK', meta: 'Miyapur · 1,200 sqft · Under Construction', leads: 31, visits: 6, status: 'Active' },
    { emoji: '✨', price: '₹95L', name: 'Golkonda Heights — 3BHK', meta: 'Kokapet · 1,450 sqft · Ready to move', leads: 16, visits: 2, status: 'Paused' },
    { emoji: '🏠', price: '₹48L', name: 'Rainbow Vistas — 1BHK', meta: 'Kompally · 650 sqft · Under Construction', leads: 11, visits: 1, status: 'Active' },
  ];

  return (
    <div className="page-anim">
      <div className="ph"><h2>🏘️ My Listings</h2><p>Properties you're actively marketing and selling</p></div>
      <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
        <button className="btn btn-p">+ Add Listing</button>
        <button className="btn btn-o">📤 Import from Excel</button>
      </div>
      <div className="g31">
        {listings.map((l, i) => (
          <div className="listing-card" key={i}>
            <div className="listing-img">{l.emoji}</div>
            <div className="listing-body">
              <div className="listing-price">{l.price}</div>
              <div className="listing-name">{l.name}</div>
              <div className="listing-meta">{l.meta}</div>
              <div className="listing-stats">
                <div className="lst"><div className="lst-val">{l.leads}</div><div className="lst-lbl">Leads</div></div>
                <div className="lst"><div className="lst-val">{l.visits}</div><div className="lst-lbl">Site Visits</div></div>
                <div className="lst"><div className="lst-val" style={{ fontSize: 10, color: l.status === 'Active' ? 'var(--green)' : 'var(--amber)' }}>{l.status}</div><div className="lst-lbl">Status</div></div>
              </div>
              <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
                <button className="btn btn-o btn-sm" style={{ flex: 1, justifyContent: 'center' }}>Edit</button>
                <button className="btn btn-p btn-sm" style={{ flex: 1, justifyContent: 'center' }}>Boost Ad</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Reviews.jsx
export function Reviews() {
  const reviews = [
    { platform: '⭐', name: 'Ravi Shankar', stars: 5, text: 'Excellent service! Found my dream 2BHK in Gachibowli within 2 weeks. Very professional and honest.', date: '2 days ago' },
    { platform: '📘', name: 'Sunita Reddy', stars: 5, text: 'Best channel partner in Hyderabad! Very transparent about pricing and paperwork. Highly recommend.', date: '5 days ago' },
    { platform: '⭐', name: 'Karan Mehta', stars: 4, text: 'Good experience overall. Response time could be faster but the property suggestions were spot on.', date: '1 week ago' },
    { platform: '📸', name: 'Priya Sharma', stars: 5, text: 'Amazing experience! The virtual tour feature saved us so much time. Booked our 3BHK in Tellapur!', date: '2 weeks ago' },
  ];

  return (
    <div className="page-anim">
      <div className="ph"><h2>⭐ Reviews Manager</h2><p>Your reputation across Google, Facebook, and Instagram</p></div>
      <div className="sg3" style={{ marginBottom: 18 }}>
        <div className="sc g"><div className="slbl">Overall Rating</div><div className="sval">4.8</div><div className="schg up">↑ Out of 5.0</div><div className="sico">⭐</div></div>
        <div className="sc b"><div className="slbl">Total Reviews</div><div className="sval">47</div><div className="schg up">↑ +16 this month</div><div className="sico">📊</div></div>
        <div className="sc a"><div className="slbl">Pending Replies</div><div className="sval">3</div><div className="schg dn">Reply today!</div><div className="sico">💬</div></div>
      </div>
      <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
        <button className="btn btn-p">✉ Request Reviews from Buyers</button>
        <button className="btn btn-o">🤖 Auto-Reply with Priya</button>
      </div>
      <div className="card">
        {reviews.map((r, i) => (
          <div className="review-item" key={i}>
            <div className="rplatform" style={{ background: 'var(--surface2)' }}>{r.platform}</div>
            <div className="rinfo">
              <div className="rname">{r.name}</div>
              <div className="rstars">{'★'.repeat(r.stars)}{'☆'.repeat(5 - r.stars)}</div>
              <div className="rtext">{r.text}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 6 }}>
                <div className="rdate">{r.date}</div>
                <button className="btn btn-g btn-sm">🤖 Reply with AI</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Support.jsx
import { useState } from 'react';

export function Support() {
  const [ticket, setTicket] = useState({ subject: '', type: 'technical', desc: '', phone: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!ticket.subject || !ticket.desc) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    setSubmitted(true);
    setLoading(false);
  };

  return (
    <div className="page-anim">
      <div className="ph"><h2>🆘 Help & Support</h2><p>We're here to help — Mon–Sat 9AM to 7PM</p></div>
      <div className="g21">
        <div>
          <div className="card" style={{ marginBottom: 16 }}>
            <div className="card-hd"><div className="card-title">🎫 Submit a Support Ticket</div></div>
            {submitted ? (
              <div style={{ textAlign: 'center', padding: '30px 20px' }}>
                <div style={{ fontSize: 32, marginBottom: 10 }}>✅</div>
                <div style={{ fontFamily: 'Syne,sans-serif', fontWeight: 800, fontSize: 15, color: 'var(--green)', marginBottom: 6 }}>Ticket Submitted!</div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>We'll reply on WhatsApp within 2 hours. Ticket #ADZ-{Math.floor(Math.random()*9000+1000)}</div>
                <button className="btn btn-o btn-sm" style={{ marginTop: 12 }} onClick={() => setSubmitted(false)}>Submit Another</button>
              </div>
            ) : (
              <div className="support-form">
                <label>Issue Type</label>
                <select value={ticket.type} onChange={e => setTicket(t => ({ ...t, type: e.target.value }))}>
                  {[['technical','Technical Problem'],['billing','Billing / Payment'],['campaign','Campaign Issue'],['feature','Feature Request'],['other','Other']].map(([v,l]) => <option key={v} value={v}>{l}</option>)}
                </select>
                <label>Subject</label>
                <input placeholder="e.g. My Google Ads campaign stopped running" value={ticket.subject} onChange={e => setTicket(t => ({ ...t, subject: e.target.value }))} />
                <label>Describe the problem</label>
                <textarea placeholder="Tell us what's happening in detail…" rows={4} value={ticket.desc} onChange={e => setTicket(t => ({ ...t, desc: e.target.value }))} />
                <label>Your WhatsApp number</label>
                <input placeholder="+91 98765 43210" value={ticket.phone} onChange={e => setTicket(t => ({ ...t, phone: e.target.value }))} />
                <div style={{ marginTop: 14 }}>
                  <button className="btn btn-p" onClick={submit} disabled={loading} style={{ width: '100%', justifyContent: 'center' }}>
                    {loading ? 'Submitting…' : '📤 Submit Ticket'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="card">
            <div className="card-hd"><div className="card-title">📞 Talk to Our Team</div></div>
            {[
              { icon: '💬', label: 'WhatsApp Support', sub: 'Mon–Sat · 9AM to 7PM', color: 'var(--green-bg)', border: 'rgba(5,150,105,.15)', btn: 'Chat Now', btnCls: 'btn-g' },
              { icon: '📞', label: 'Call Us: 040-4123-4567', sub: 'Mon–Fri · 10AM to 6PM', color: 'var(--blue-bg)', border: 'rgba(2,132,199,.15)', btn: 'Call', btnCls: 'btn-o' },
              { icon: '📧', label: 'support@adzo.in', sub: 'Reply within 4 hours', color: 'var(--surface2)', border: 'var(--border)', btn: 'Email', btnCls: 'btn-o' },
            ].map((c, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', background: c.color, border: `1px solid ${c.border}`, borderRadius: 'var(--rmd)', marginBottom: 8 }}>
                <div style={{ fontSize: 20 }}>{c.icon}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 700 }}>{c.label}</div>
                  <div style={{ fontSize: 10, color: 'var(--muted)' }}>{c.sub}</div>
                </div>
                <button className={`btn ${c.btnCls} btn-sm`}>{c.btn}</button>
              </div>
            ))}
          </div>

          <div className="card" style={{ background: 'linear-gradient(135deg,#fffbeb,#fef9c3)', borderColor: 'rgba(234,179,8,.2)' }}>
            <div className="card-hd"><div className="card-title" style={{ color: '#78350f' }}>🌟 How Others Grew with Adzo</div></div>
            <div style={{ fontSize: 12, lineHeight: 1.7, color: '#92400e' }}>
              "Within 3 months of using Adzo, my lead volume tripled and my cost per lead dropped from ₹380 to ₹175."
              <br /><strong>— Ravi Shankar, Channel Partner, Kondapur</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
