export { FollowUp as default } from './OtherPages';
