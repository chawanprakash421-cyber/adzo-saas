import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

export default function Login() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [form, setForm] = useState({ email: '', password: '', name: '', businessName: '', phone: '' });
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const submit = async () => {
    setErr(''); setLoading(true);
    try {
      if (mode === 'login') {
        await login(form.email, form.password);
      } else {
        if (!form.name || !form.businessName) { setErr('All fields required'); setLoading(false); return; }
        await register(form);
      }
    } catch (e) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-box">
        <div className="auth-logo">
          <div className="auth-logo-icon">AZ</div>
          <h1>Adzo</h1>
          <p>AI Growth Platform for Hyderabad Businesses</p>
        </div>

        {err && <div className="auth-err">⚠ {err}</div>}

        {mode === 'register' && (
          <>
            <div className="auth-field">
              <label>Your Name</label>
              <input placeholder="Prakash Reddy" value={form.name} onChange={e => set('name', e.target.value)} />
            </div>
            <div className="auth-field">
              <label>Business Name</label>
              <input placeholder="RisingRoof Properties" value={form.businessName} onChange={e => set('businessName', e.target.value)} />
            </div>
            <div className="auth-field">
              <label>Phone</label>
              <input placeholder="+91 98765 43210" value={form.phone} onChange={e => set('phone', e.target.value)} />
            </div>
          </>
        )}

        <div className="auth-field">
          <label>Email Address</label>
          <input type="email" placeholder="you@yourbusiness.com" value={form.email} onChange={e => set('email', e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} />
        </div>
        <div className="auth-field">
          <label>Password</label>
          <input type="password" placeholder="••••••••" value={form.password} onChange={e => set('password', e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} />
        </div>

        <button className="btn btn-p" style={{ width: '100%', justifyContent: 'center', padding: '11px' }} onClick={submit} disabled={loading}>
          {loading ? <><span className="spinner" style={{ width: 14, height: 14 }} /> &nbsp; Please wait…</> : mode === 'login' ? '→ Sign In' : '→ Create Account'}
        </button>

        <div className="auth-switch">
          {mode === 'login' ? (
            <>Don't have an account? <button onClick={() => { setMode('register'); setErr(''); }}>Register Free →</button></>
          ) : (
            <>Already have an account? <button onClick={() => { setMode('login'); setErr(''); }}>Sign In →</button></>
          )}
        </div>

        {mode === 'login' && (
          <div style={{ textAlign: 'center', marginTop: 12, fontSize: 11, color: 'var(--muted)' }}>
            Demo admin: <strong>admin@adzo.in</strong> / <strong>admin123</strong>
          </div>
        )}
      </div>
    </div>
  );
}
