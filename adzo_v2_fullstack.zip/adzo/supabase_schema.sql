-- ═══════════════════════════════════════════════════════════
-- ADZO v2 — SUPABASE SQL SCHEMA
-- Paste this entire file into Supabase → SQL Editor → Run
-- ═══════════════════════════════════════════════════════════

-- ── EXTENSIONS ───────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── BUSINESSES ───────────────────────────────────────────────
create table if not exists businesses (
  id            uuid primary key default uuid_generate_v4(),
  name          text not null,
  phone         text,
  email         text,
  locality      text,
  business_type text default 'real_estate',
  plan          text not null default 'trial'
                  check (plan in ('trial','starter','growth','pro','enterprise')),
  status        text not null default 'active'
                  check (status in ('active','inactive','suspended')),
  logo_url      text,
  website_url   text,
  gstin         text,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── USERS ─────────────────────────────────────────────────────
create table if not exists users (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid references businesses(id) on delete cascade,
  email         text not null unique,
  password_hash text not null,
  name          text not null,
  phone         text,
  role          text not null default 'owner'
                  check (role in ('admin','owner','staff')),
  plan          text not null default 'trial',
  avatar_url    text,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── LEADS ─────────────────────────────────────────────────────
create table if not exists leads (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid not null references businesses(id) on delete cascade,
  name          text not null,
  phone         text not null,
  email         text,
  source        text default 'manual'
                  check (source in ('google','meta','whatsapp','organic','manual','webhook','referral')),
  status        text not null default 'new'
                  check (status in ('new','contacted','qualified','site_visit','negotiation','converted','lost')),
  interest      text,
  property_type text,
  locality      text,
  budget        text,
  score         integer default 50 check (score >= 0 and score <= 100),
  notes         text,
  assigned_to   uuid references users(id),
  last_contact  timestamptz default now(),
  message       text,
  hubspot_id    text,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── CONTENT LIBRARY ───────────────────────────────────────────
create table if not exists content_library (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid not null references businesses(id) on delete cascade,
  type          text not null
                  check (type in ('whatsapp','instagram','google_ad','email','facebook_reel','follow_up_script','ugadi_offer','other')),
  content       text not null,
  context       text,
  status        text default 'draft'
                  check (status in ('draft','approved','published','archived')),
  created_by    uuid references users(id),
  scheduled_at  timestamptz,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── CAMPAIGNS ─────────────────────────────────────────────────
create table if not exists campaigns (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid not null references businesses(id) on delete cascade,
  name          text not null,
  platform      text not null
                  check (platform in ('google','meta','whatsapp','email','other')),
  status        text not null default 'draft'
                  check (status in ('draft','running','paused','completed')),
  budget_daily  numeric(10,2) default 0,
  budget_total  numeric(10,2) default 0,
  spend         numeric(10,2) default 0,
  leads_count   integer default 0,
  cpl           numeric(10,2),
  targeting     jsonb,
  external_id   text,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── WALLETS ───────────────────────────────────────────────────
create table if not exists wallets (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid not null unique references businesses(id) on delete cascade,
  balance       numeric(12,2) not null default 0,
  total_topped  numeric(12,2) default 0,
  total_spent   numeric(12,2) default 0,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── WALLET TRANSACTIONS ───────────────────────────────────────
create table if not exists wallet_transactions (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid not null references businesses(id) on delete cascade,
  type          text not null check (type in ('credit','debit')),
  amount        numeric(10,2) not null,
  description   text,
  payment_id    text,
  order_id      text,
  campaign_id   uuid references campaigns(id),
  created_at    timestamptz default now()
);

-- ── LISTINGS ──────────────────────────────────────────────────
create table if not exists listings (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid not null references businesses(id) on delete cascade,
  name          text not null,
  price         numeric(14,2),
  price_text    text,
  property_type text,
  locality      text,
  area_sqft     integer,
  bedrooms      integer,
  bathrooms     integer,
  status        text default 'active' check (status in ('active','paused','sold')),
  possession    text,
  description   text,
  image_url     text,
  leads_count   integer default 0,
  site_visits   integer default 0,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── REVIEWS ───────────────────────────────────────────────────
create table if not exists reviews (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid not null references businesses(id) on delete cascade,
  platform      text check (platform in ('google','facebook','instagram','direct')),
  reviewer_name text,
  rating        integer check (rating >= 1 and rating <= 5),
  review_text   text,
  reply         text,
  replied_at    timestamptz,
  review_date   date,
  external_id   text,
  created_at    timestamptz default now()
);

-- ── SUPPORT TICKETS ───────────────────────────────────────────
create table if not exists support_tickets (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid references businesses(id) on delete set null,
  user_id       uuid references users(id) on delete set null,
  subject       text not null,
  type          text default 'technical',
  description   text not null,
  phone         text,
  status        text default 'open' check (status in ('open','in_progress','resolved','closed')),
  ticket_number text unique default 'ADZ-' || floor(random()*9000+1000)::text,
  resolved_at   timestamptz,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── ACTIVITY LOG ──────────────────────────────────────────────
create table if not exists activity_log (
  id            uuid primary key default uuid_generate_v4(),
  business_id   uuid references businesses(id) on delete cascade,
  user_id       uuid references users(id),
  action        text not null,
  entity_type   text,
  entity_id     uuid,
  meta          jsonb,
  created_at    timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- INDEXES — For fast queries
-- ═══════════════════════════════════════════════════════════
create index if not exists idx_leads_business_id     on leads(business_id);
create index if not exists idx_leads_status          on leads(status);
create index if not exists idx_leads_created_at      on leads(created_at desc);
create index if not exists idx_leads_last_contact    on leads(last_contact);
create index if not exists idx_leads_source          on leads(source);
create index if not exists idx_content_business_id   on content_library(business_id);
create index if not exists idx_campaigns_business_id on campaigns(business_id);
create index if not exists idx_wallet_txn_business   on wallet_transactions(business_id);
create index if not exists idx_listings_business_id  on listings(business_id);
create index if not exists idx_reviews_business_id   on reviews(business_id);
create index if not exists idx_users_email           on users(email);
create index if not exists idx_users_business_id     on users(business_id);

-- ═══════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS)
-- ═══════════════════════════════════════════════════════════
-- NOTE: Adzo uses server-side auth (JWT + Express).
-- The backend uses the SERVICE ROLE key (bypasses RLS).
-- Enable RLS below only if you add Supabase Auth later.

-- alter table businesses enable row level security;
-- alter table users enable row level security;
-- alter table leads enable row level security;
-- alter table content_library enable row level security;
-- alter table campaigns enable row level security;
-- alter table wallets enable row level security;
-- alter table wallet_transactions enable row level security;
-- alter table listings enable row level security;
-- alter table reviews enable row level security;

-- ═══════════════════════════════════════════════════════════
-- SEED DATA — Demo admin + first business
-- ═══════════════════════════════════════════════════════════

-- Admin user (password: admin123)
-- bcrypt hash for "admin123" with 12 rounds:
insert into businesses (id, name, phone, plan, status, business_type)
values (
  '00000000-0000-0000-0000-000000000001',
  'Adzo Platform',
  '+91 9999999999',
  'enterprise',
  'active',
  'saas'
) on conflict do nothing;

insert into users (id, business_id, email, password_hash, name, role, plan)
values (
  '00000000-0000-0000-0000-000000000002',
  '00000000-0000-0000-0000-000000000001',
  'admin@adzo.in',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQyCgSGjBoNDe19OKkGD7XCa6',
  'Adzo Admin',
  'admin',
  'enterprise'
) on conflict do nothing;

-- RisingRoof demo client
insert into businesses (id, name, phone, plan, status, locality, business_type)
values (
  '00000000-0000-0000-0000-000000000010',
  'RisingRoof Properties',
  '+91 9876543210',
  'growth',
  'active',
  'Kondapur, Hyderabad',
  'real_estate'
) on conflict do nothing;

insert into users (id, business_id, email, password_hash, name, role, plan)
values (
  '00000000-0000-0000-0000-000000000011',
  '00000000-0000-0000-0000-000000000010',
  'prakash@risingroof.in',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQyCgSGjBoNDe19OKkGD7XCa6',
  'Prakash',
  'owner',
  'growth'
) on conflict do nothing;

-- Wallet for RisingRoof
insert into wallets (business_id, balance, total_topped)
values ('00000000-0000-0000-0000-000000000010', 4250, 10000)
on conflict do nothing;

-- Sample leads
insert into leads (business_id, name, phone, source, status, interest, locality, budget, score, last_contact)
values
  ('00000000-0000-0000-0000-000000000010', 'Sachin Chavan',  '+91 9000000001', 'google',   'new',       '2BHK', 'Gachibowli', '₹80L',  92, now() - interval '2 hours'),
  ('00000000-0000-0000-0000-000000000010', 'Vinay Kumar',    '+91 9000000002', 'meta',     'contacted', '3BHK', 'Kondapur',   '₹90L',  75, now() - interval '3 days'),
  ('00000000-0000-0000-0000-000000000010', 'Deepa Pillai',   '+91 9000000003', 'google',   'contacted', '2BHK', 'Gachibowli', '₹70L',  68, now() - interval '2 days'),
  ('00000000-0000-0000-0000-000000000010', 'Ramesh Kapoor',  '+91 9000000004', 'whatsapp', 'new',       '3BHK', 'Tellapur',   '₹80L',  60, now() - interval '1 day'),
  ('00000000-0000-0000-0000-000000000010', 'Priya Sharma',   '+91 9000000005', 'meta',     'converted', '2BHK', 'Financial District', '₹75L', 88, now() - interval '5 days'),
  ('00000000-0000-0000-0000-000000000010', 'Kiran Reddy',    '+91 9000000006', 'google',   'new',       '2BHK', 'Kokapet',    '₹1.2Cr', 85, now() - interval '6 hours'),
  ('00000000-0000-0000-0000-000000000010', 'Anand Verma',    '+91 9000000007', 'organic',  'contacted', '3BHK', 'Miyapur',    '₹65L',  50, now() - interval '4 days')
on conflict do nothing;

-- Sample listings
insert into listings (business_id, name, price, price_text, property_type, locality, area_sqft, bedrooms, status, possession)
values
  ('00000000-0000-0000-0000-000000000010', 'Prestige Sky Vista', 7200000, '₹72L', '2BHK', 'Financial District', 1250, 2, 'active', 'Ready to Move'),
  ('00000000-0000-0000-0000-000000000010', 'My Home Vihanga',    5500000, '₹55L', '2BHK', 'Tellapur',           1150, 2, 'active', 'Under Construction'),
  ('00000000-0000-0000-0000-000000000010', 'Aparna Sarovar',    12000000, '₹1.2Cr', '3BHK', 'Nallagandla',     1680, 3, 'active', 'Ready to Move')
on conflict do nothing;

-- ═══════════════════════════════════════════════════════════
-- DONE ✅
-- Credentials:
--   Admin:      admin@adzo.in     / admin123
--   Demo client: prakash@risingroof.in / admin123
-- ═══════════════════════════════════════════════════════════
