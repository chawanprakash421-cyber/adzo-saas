# Adzo v2 — AI Marketing Platform

Full-stack SaaS for Hyderabad local businesses.  
**Frontend:** React + Vite → Vercel  
**Backend:** Node.js + Express → Render  
**Database:** Supabase (PostgreSQL)

---

## 🗂 Project Structure

```
adzo/
├── backend/                  ← Node.js / Express API
│   ├── server.js             ← Entry point
│   ├── routes/
│   │   ├── auth.js           ← Register, Login, /me
│   │   ├── leads.js          ← Full CRUD + stats
│   │   ├── content.js        ← Claude AI generation + Priya chat
│   │   ├── campaigns.js      ← Campaign CRUD
│   │   ├── wallet.js         ← Razorpay + wallet top-up
│   │   └── admin.js          ← Platform overview (admin only)
│   ├── middleware/auth.js    ← JWT guard + adminOnly
│   ├── db/supabase.js        ← Supabase client
│   ├── .env.example          ← All required env vars
│   └── render.yaml           ← Render deploy config
│
├── frontend/                 ← React + Vite
│   ├── src/
│   │   ├── App.jsx           ← Router + auth guard
│   │   ├── api.js            ← All backend API calls
│   │   ├── index.css         ← Full design system
│   │   ├── contexts/
│   │   │   └── AuthContext.jsx
│   │   ├── components/
│   │   │   ├── Layout.jsx    ← Sidebar + topbar
│   │   │   └── PriyaChat.jsx ← Floating AI chat
│   │   └── pages/
│   │       ├── Login.jsx
│   │       ├── Home.jsx
│   │       ├── Leads.jsx
│   │       ├── ContentStudio.jsx
│   │       ├── Analytics.jsx
│   │       ├── Wallet.jsx
│   │       ├── OtherPages.jsx  ← FollowUp, Campaigns, Listings, Reviews, Support
│   │       └── admin/
│   │           ├── AdminOverview.jsx
│   │           ├── AdminUsers.jsx
│   │           ├── AdminRevenue.jsx
│   │           └── AdminSystem.jsx
│   ├── vercel.json
│   └── .env.example
│
└── supabase_schema.sql       ← Paste into Supabase SQL Editor → Run
```

---

## 🚀 Deployment Guide

### Step 1 — Supabase (Database)

1. Go to [supabase.com](https://supabase.com) → New Project
2. Open **SQL Editor** → paste entire `supabase_schema.sql` → **Run**
3. Copy from **Settings → API**:
   - `Project URL` → `SUPABASE_URL`
   - `service_role` key → `SUPABASE_SERVICE_KEY`

### Step 2 — Backend on Render

1. Push `backend/` folder to a GitHub repo
2. Go to [render.com](https://render.com) → **New Web Service** → connect repo
3. Render auto-detects `render.yaml`
4. Add these **Environment Variables** in Render dashboard:

| Key | Value |
|-----|-------|
| `SUPABASE_URL` | From Supabase |
| `SUPABASE_SERVICE_KEY` | From Supabase (service_role) |
| `JWT_SECRET` | Any random 32+ char string |
| `ANTHROPIC_API_KEY` | From console.anthropic.com |
| `RAZORPAY_KEY_ID` | From Razorpay dashboard |
| `RAZORPAY_KEY_SECRET` | From Razorpay dashboard |
| `FRONTEND_URL` | Your Vercel URL (add after Step 3) |

5. Deploy → note your Render URL: `https://adzo-backend.onrender.com`

### Step 3 — Frontend on Vercel

1. Push `frontend/` folder to GitHub
2. Go to [vercel.com](https://vercel.com) → **New Project** → import repo
3. Add **Environment Variables**:

| Key | Value |
|-----|-------|
| `VITE_API_URL` | `https://adzo-backend.onrender.com/api` |
| `VITE_RAZORPAY_KEY_ID` | Your Razorpay public key |

4. Deploy → Vercel auto-runs `npm run build`
5. Copy Vercel URL → go back to Render → set `FRONTEND_URL`

---

## 🔐 Demo Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@adzo.in | admin123 |
| Client | prakash@risingroof.in | admin123 |

---

## 🛠 Local Development

```bash
# Terminal 1 — Backend
cd backend
cp .env.example .env     # fill in your keys
npm install
npm run dev              # runs on http://localhost:5000

# Terminal 2 — Frontend
cd frontend
cp .env.example .env     # leave VITE_API_URL blank for local
npm install
npm run dev              # runs on http://localhost:5173
```

Vite proxy config automatically forwards `/api/*` → `http://localhost:5000`

---

## 📡 API Endpoints

```
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/me

GET    /api/leads              ?status=&source=&search=&page=&limit=
POST   /api/leads
PUT    /api/leads/:id
DELETE /api/leads/:id
GET    /api/leads/filter/followup
GET    /api/leads/stats/summary

POST   /api/content/generate   { type, context, tone }
POST   /api/content/priya      { message, history[] }
GET    /api/content
PUT    /api/content/:id

GET    /api/campaigns
POST   /api/campaigns
PUT    /api/campaigns/:id

GET    /api/wallet
POST   /api/wallet/order       { amount }
POST   /api/wallet/verify      { razorpay_* }
GET    /api/wallet/plans

GET    /api/admin/overview     [admin only]
GET    /api/admin/businesses   [admin only]
GET    /api/admin/users        [admin only]
GET    /api/admin/revenue      [admin only]
GET    /api/admin/system       [admin only]

POST   /webhook/lead           n8n webhook for ad-click leads
GET    /health                 uptime check
```

---

## 🤖 n8n Workflow Connections

Your 4 n8n workflows connect to these endpoints:

| Workflow | Endpoint |
|----------|----------|
| New Lead Captured (ad click) | `POST /webhook/lead` |
| Follow-up Reminder | `GET /api/leads/filter/followup` |
| AI Content Creation | `POST /api/content/generate` |
| Wallet & Ad Budget | `POST /api/wallet/verify` |

---

## 📦 Tech Stack Summary

| Layer | Technology |
|-------|------------|
| Frontend | React 18 + Vite + React Router v6 |
| Styling | Custom CSS (Syne + DM Sans fonts) |
| Charts | Chart.js + react-chartjs-2 |
| Backend | Node.js + Express |
| Database | Supabase (PostgreSQL) |
| AI | Anthropic Claude API (claude-sonnet-4) |
| Payments | Razorpay |
| Auth | JWT (bcrypt + jsonwebtoken) |
| Deploy FE | Vercel |
| Deploy BE | Render |
| Automation | n8n (self-hosted or cloud) |
