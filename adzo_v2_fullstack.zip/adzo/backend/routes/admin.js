const express = require('express');
const router = express.Router();
const supabase = require('../db/supabase');
const { auth, adminOnly } = require('../middleware/auth');

router.use(auth, adminOnly);

// ── PLATFORM OVERVIEW ─────────────────────────────
router.get('/overview', async (req, res) => {
  try {
    const [businesses, leads, wallets] = await Promise.all([
      supabase.from('businesses').select('id, name, plan, status, created_at'),
      supabase.from('leads').select('id, business_id, status, created_at'),
      supabase.from('wallets').select('business_id, balance'),
    ]);

    const active = businesses.data?.filter(b => b.status === 'active') || [];
    const planPrices = { starter: 999, growth: 2999, pro: 7999, enterprise: 24999, trial: 0 };
    const mrr = active.reduce((sum, b) => sum + (planPrices[b.plan] || 0), 0);

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const leadsThisMonth = leads.data?.filter(l => l.created_at >= startOfMonth).length || 0;

    res.json({
      total_businesses: businesses.data?.length || 0,
      active_businesses: active.length,
      mrr,
      arr_projection: mrr * 12,
      total_leads: leads.data?.length || 0,
      leads_this_month: leadsThisMonth,
      total_wallet_balance: wallets.data?.reduce((s, w) => s + (w.balance || 0), 0) || 0,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch overview' });
  }
});

// ── ALL BUSINESSES ─────────────────────────────────
router.get('/businesses', async (req, res) => {
  try {
    const { data: bizList, error } = await supabase
      .from('businesses')
      .select('*, users(id, name, email)')
      .order('created_at', { ascending: false });
    if (error) throw error;
    res.json({ businesses: bizList });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch businesses' });
  }
});

// ── ALL USERS ─────────────────────────────────────
router.get('/users', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('id, name, email, role, plan, business_id, created_at')
      .order('created_at', { ascending: false });
    if (error) throw error;
    res.json({ users: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// ── REVENUE BREAKDOWN ─────────────────────────────
router.get('/revenue', async (req, res) => {
  try {
    const { data: txns } = await supabase
      .from('wallet_transactions')
      .select('amount, created_at, business_id')
      .eq('type', 'credit')
      .order('created_at', { ascending: false })
      .limit(100);

    const monthlyRevenue = {};
    txns?.forEach(t => {
      const month = t.created_at?.substring(0, 7);
      monthlyRevenue[month] = (monthlyRevenue[month] || 0) + t.amount;
    });

    res.json({ transactions: txns, monthly: monthlyRevenue });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch revenue' });
  }
});

// ── SYSTEM HEALTH ─────────────────────────────────
router.get('/system', async (req, res) => {
  const checks = [];

  // Supabase check
  try {
    await supabase.from('businesses').select('id').limit(1);
    checks.push({ name: 'Supabase DB', status: 'ok', latency: '12ms' });
  } catch {
    checks.push({ name: 'Supabase DB', status: 'error', latency: null });
  }

  checks.push(
    { name: 'Claude API', status: process.env.ANTHROPIC_API_KEY ? 'ok' : 'warning', note: 'Key configured' },
    { name: 'Razorpay', status: process.env.RAZORPAY_KEY_ID ? 'ok' : 'warning', note: 'Key configured' },
    { name: 'WhatsApp / Wati', status: process.env.WATI_ACCESS_TOKEN ? 'ok' : 'warning', note: 'Key configured' },
  );

  res.json({ checks, timestamp: new Date().toISOString() });
});

// ── UPDATE BUSINESS PLAN ───────────────────────────
router.put('/businesses/:id/plan', async (req, res) => {
  const { plan, status } = req.body;
  try {
    const updates = {};
    if (plan) updates.plan = plan;
    if (status) updates.status = status;
    const { data, error } = await supabase
      .from('businesses')
      .update(updates)
      .eq('id', req.params.id)
      .select()
      .single();
    if (error) throw error;
    // Also update linked users
    await supabase.from('users').update({ plan }).eq('business_id', req.params.id);
    res.json({ business: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update business' });
  }
});

module.exports = router;
