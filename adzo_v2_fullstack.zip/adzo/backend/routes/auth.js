const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const supabase = require('../db/supabase');
const { auth } = require('../middleware/auth');

// ── REGISTER ─────────────────────────────────────
router.post('/register', async (req, res) => {
  const { email, password, name, businessName, phone } = req.body;
  if (!email || !password || !name || !businessName) {
    return res.status(400).json({ error: 'All fields required' });
  }

  try {
    // Check email exists
    const { data: existing } = await supabase
      .from('users')
      .select('id')
      .eq('email', email)
      .single();
    if (existing) return res.status(409).json({ error: 'Email already registered' });

    // Create business first
    const { data: biz, error: bizErr } = await supabase
      .from('businesses')
      .insert({ name: businessName, phone, plan: 'trial', status: 'active' })
      .select()
      .single();
    if (bizErr) throw bizErr;

    // Hash password
    const hash = await bcrypt.hash(password, 12);

    // Create user
    const { data: user, error: userErr } = await supabase
      .from('users')
      .insert({
        email,
        password_hash: hash,
        name,
        role: 'owner',
        business_id: biz.id,
        plan: 'trial',
      })
      .select('id, email, name, role, business_id, plan')
      .single();
    if (userErr) throw userErr;

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.status(201).json({ token, user });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// ── LOGIN ─────────────────────────────────────────
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

  try {
    const { data: user, error } = await supabase
      .from('users')
      .select('id, email, name, role, business_id, plan, password_hash')
      .eq('email', email)
      .single();

    if (error || !user) return res.status(401).json({ error: 'Invalid credentials' });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const { password_hash: _, ...safeUser } = user;
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.json({ token, user: safeUser });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

// ── ME ────────────────────────────────────────────
router.get('/me', auth, async (req, res) => {
  try {
    // Get business info too
    const { data: biz } = await supabase
      .from('businesses')
      .select('*')
      .eq('id', req.user.business_id)
      .single();
    res.json({ user: req.user, business: biz });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// ── UPDATE PROFILE ────────────────────────────────
router.put('/profile', auth, async (req, res) => {
  const { name, phone } = req.body;
  try {
    const { data, error } = await supabase
      .from('users')
      .update({ name, phone, updated_at: new Date() })
      .eq('id', req.user.id)
      .select('id, email, name, role, business_id, plan')
      .single();
    if (error) throw error;
    res.json({ user: data });
  } catch (err) {
    res.status(500).json({ error: 'Profile update failed' });
  }
});

module.exports = router;
