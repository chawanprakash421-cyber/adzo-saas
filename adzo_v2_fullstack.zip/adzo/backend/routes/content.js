const express = require('express');
const router = express.Router();
const Anthropic = require('@anthropic-ai/sdk');
const supabase = require('../db/supabase');
const { auth } = require('../middleware/auth');

router.use(auth);
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── GENERATE CONTENT (AI) ─────────────────────────
router.post('/generate', async (req, res) => {
  const { type, context, tone = 'friendly', language = 'English' } = req.body;
  if (!type || !context) return res.status(400).json({ error: 'type and context required' });

  // Fetch business info for personalization
  const { data: biz } = await supabase
    .from('businesses')
    .select('name, locality, property_types')
    .eq('id', req.user.business_id)
    .single();

  const prompts = {
    whatsapp: `You are writing a WhatsApp message for ${biz?.name || 'a real estate business'} in Hyderabad.
Context: ${context}
Tone: ${tone}. Language: ${language}. Keep it under 200 characters. Use 1-2 relevant emojis. End with a clear call-to-action. No markdown formatting.`,

    instagram: `Write an Instagram post caption for ${biz?.name || 'a real estate business'} in Hyderabad.
Context: ${context}
Include: compelling hook first line, 3-4 lines of body, 5-8 hashtags at the end.
Tone: ${tone}. Use emojis naturally. No asterisks or markdown.`,

    google_ad: `Write a Google Search Ad for a real estate business in Hyderabad.
Context: ${context}
Format: Headline 1 (max 30 chars) | Headline 2 (max 30 chars) | Headline 3 (max 30 chars)
Description (max 90 chars)
Keep it punchy, include a number or offer if possible.`,

    email: `Write a marketing email for ${biz?.name || 'a real estate business'} in Hyderabad.
Context: ${context}
Include: Subject line, greeting, 2-3 body paragraphs, clear CTA, professional sign-off.
Tone: ${tone}. Professional but warm.`,

    facebook_reel: `Write a Facebook/Instagram Reel script for ${biz?.name || 'a real estate business'} in Hyderabad.
Context: ${context}
Format: Hook (first 3 seconds), Main content (20-30 seconds), CTA (5 seconds).
Include on-screen text suggestions. Tone: ${tone}.`,

    follow_up_script: `Write a phone call follow-up script for a real estate agent in Hyderabad.
Context: ${context}
Keep it natural, conversational. Include: opener, reason for call, value proposition, ask for next step.
Under 200 words. No jargon.`,

    ugadi_offer: `Create a Ugadi festival promotional content for ${biz?.name || 'a real estate business'} in Hyderabad.
Context: ${context}
Include: festive greeting in Telugu + English, special offer/incentive, urgency. WhatsApp-friendly format.`,
  };

  const prompt = prompts[type] || `Generate ${type} content for a real estate business. Context: ${context}`;

  try {
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 500,
      messages: [{ role: 'user', content: prompt }],
    });

    const content = message.content[0]?.text || '';

    // Save to content library
    const { data: saved } = await supabase
      .from('content_library')
      .insert({
        business_id: req.user.business_id,
        type,
        content,
        context,
        status: 'draft',
        created_by: req.user.id,
      })
      .select()
      .single();

    res.json({ content, id: saved?.id });
  } catch (err) {
    console.error('Content generation error:', err);
    res.status(500).json({ error: 'AI generation failed. Check your API key.' });
  }
});

// ── PRIYA AI CHAT ────────────────────────────────
router.post('/priya', async (req, res) => {
  const { message, history = [] } = req.body;
  if (!message) return res.status(400).json({ error: 'Message required' });

  const { data: biz } = await supabase
    .from('businesses')
    .select('name, locality, plan')
    .eq('id', req.user.business_id)
    .single();

  const { data: stats } = await supabase
    .from('leads')
    .select('id, status, created_at')
    .eq('business_id', req.user.business_id)
    .limit(100);

  const total = stats?.length || 0;
  const converted = stats?.filter(l => l.status === 'converted').length || 0;

  const systemPrompt = `You are Priya, a warm, smart AI business manager for ${biz?.name || 'a business'} on the Adzo platform in Hyderabad, India.

Business context:
- Business: ${biz?.name}, Plan: ${biz?.plan}
- Total leads: ${total}, Converted: ${converted}
- Focus area: Real estate / local businesses in Hyderabad

Your role: Help with marketing strategy, content writing, lead follow-up advice, campaign ideas, and general business growth.
Style: Friendly, direct, practical. Use plain English. Add 1-2 emojis per response. 
Keep responses concise (under 200 words) unless asked for detail.
Always tie advice to Hyderabad market context when relevant.`;

  const messages = [
    ...history.slice(-6),
    { role: 'user', content: message },
  ];

  try {
    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 400,
      system: systemPrompt,
      messages,
    });

    const reply = response.content[0]?.text || 'Sorry, I could not process that.';
    res.json({ reply });
  } catch (err) {
    console.error('Priya chat error:', err);
    res.status(500).json({ error: 'Priya is unavailable right now.' });
  }
});

// ── GET CONTENT LIBRARY ────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('content_library')
      .select('*')
      .eq('business_id', req.user.business_id)
      .order('created_at', { ascending: false })
      .limit(30);
    if (error) throw error;
    res.json({ items: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch content library' });
  }
});

// ── UPDATE CONTENT STATUS ──────────────────────────
router.put('/:id', async (req, res) => {
  const { status, content } = req.body;
  try {
    const { data, error } = await supabase
      .from('content_library')
      .update({ status, content, updated_at: new Date() })
      .eq('id', req.params.id)
      .eq('business_id', req.user.business_id)
      .select()
      .single();
    if (error) throw error;
    res.json({ item: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update content' });
  }
});

module.exports = router;
