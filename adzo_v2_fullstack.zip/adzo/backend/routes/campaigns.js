const express = require('express');
const router = express.Router();
const supabase = require('../db/supabase');
const { auth } = require('../middleware/auth');

router.use(auth);

router.get('/', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('campaigns')
      .select('*')
      .eq('business_id', req.user.business_id)
      .order('created_at', { ascending: false });
    if (error) throw error;
    res.json({ campaigns: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch campaigns' });
  }
});

router.post('/', async (req, res) => {
  const { name, platform, budget_daily, budget_total, targeting, status = 'draft' } = req.body;
  if (!name || !platform) return res.status(400).json({ error: 'Name and platform required' });
  try {
    const { data, error } = await supabase
      .from('campaigns')
      .insert({ business_id: req.user.business_id, name, platform, budget_daily, budget_total, targeting, status })
      .select()
      .single();
    if (error) throw error;
    res.status(201).json({ campaign: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create campaign' });
  }
});

router.put('/:id', async (req, res) => {
  const allowed = ['name','status','budget_daily','budget_total','targeting','leads_count','spend','cpl'];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });
  updates.updated_at = new Date();
  try {
    const { data, error } = await supabase
      .from('campaigns')
      .update(updates)
      .eq('id', req.params.id)
      .eq('business_id', req.user.business_id)
      .select()
      .single();
    if (error) throw error;
    res.json({ campaign: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update campaign' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await supabase.from('campaigns').delete()
      .eq('id', req.params.id).eq('business_id', req.user.business_id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete campaign' });
  }
});

module.exports = router;
