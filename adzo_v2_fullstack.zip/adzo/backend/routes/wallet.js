const express = require('express');
const router = express.Router();
const Razorpay = require('razorpay');
const crypto = require('crypto');
const supabase = require('../db/supabase');
const { auth } = require('../middleware/auth');

router.use(auth);

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// ── GET WALLET ────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { data: wallet } = await supabase
      .from('wallets')
      .select('*')
      .eq('business_id', req.user.business_id)
      .single();

    const { data: txns } = await supabase
      .from('wallet_transactions')
      .select('*')
      .eq('business_id', req.user.business_id)
      .order('created_at', { ascending: false })
      .limit(20);

    res.json({ wallet, transactions: txns || [] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch wallet' });
  }
});

// ── CREATE RAZORPAY ORDER ─────────────────────────
router.post('/order', async (req, res) => {
  const { amount } = req.body; // amount in INR
  if (!amount || amount < 100) return res.status(400).json({ error: 'Minimum ₹100' });

  try {
    const order = await razorpay.orders.create({
      amount: amount * 100, // paise
      currency: 'INR',
      receipt: `adzo_${req.user.business_id}_${Date.now()}`,
      notes: { business_id: req.user.business_id, user_id: req.user.id },
    });
    res.json({ order, key: process.env.RAZORPAY_KEY_ID });
  } catch (err) {
    console.error('Razorpay order error:', err);
    res.status(500).json({ error: 'Payment initiation failed' });
  }
});

// ── VERIFY PAYMENT + TOP UP WALLET ───────────────
router.post('/verify', async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, amount } = req.body;

  const expectedSig = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expectedSig !== razorpay_signature) {
    return res.status(400).json({ error: 'Payment verification failed' });
  }

  try {
    // Upsert wallet balance
    const { data: existing } = await supabase
      .from('wallets')
      .select('balance')
      .eq('business_id', req.user.business_id)
      .single();

    const newBalance = (existing?.balance || 0) + Number(amount);

    await supabase.from('wallets').upsert({
      business_id: req.user.business_id,
      balance: newBalance,
      updated_at: new Date(),
    }, { onConflict: 'business_id' });

    // Log transaction
    await supabase.from('wallet_transactions').insert({
      business_id: req.user.business_id,
      type: 'credit',
      amount: Number(amount),
      description: 'Wallet top-up via Razorpay',
      payment_id: razorpay_payment_id,
      order_id: razorpay_order_id,
    });

    res.json({ success: true, newBalance });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update wallet' });
  }
});

// ── SUBSCRIPTION PLANS ────────────────────────────
router.get('/plans', async (req, res) => {
  const plans = [
    { id: 'starter', name: 'Starter', price: 999, features: ['50 leads/month','WhatsApp auto-reply','1 campaign','Basic reports'] },
    { id: 'growth', name: 'Growth', price: 2999, features: ['200 leads/month','AI content generation','3 campaigns','Follow-up automation','Priority support'] },
    { id: 'pro', name: 'Pro', price: 7999, features: ['Unlimited leads','Full AI content suite','Unlimited campaigns','Advanced analytics','Competitor watch','Dedicated manager'] },
    { id: 'enterprise', name: 'Enterprise', price: 24999, features: ['Everything in Pro','Custom integrations','White-label option','API access','SLA guarantee'] },
  ];
  res.json({ plans });
});

module.exports = router;
