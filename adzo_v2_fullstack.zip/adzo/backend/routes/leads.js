const express = require('express');
const router = express.Router();
const supabase = require('../db/supabase');
const { auth } = require('../middleware/auth');

// All routes require auth
router.use(auth);

// ── GET ALL LEADS ─────────────────────────────────
router.get('/', async (req, res) => {
  const { status, source, search, page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;

  try {
    let query = supabase
      .from('leads')
      .select('*', { count: 'exact' })
      .eq('business_id', req.user.business_id)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (status) query = query.eq('status', status);
    if (source) query = query.eq('source', source);
    if (search) query = query.ilike('name', `%${search}%`);

    const { data, error, count } = await query;
    if (error) throw error;
    res.json({ leads: data, total: count, page: Number(page), limit: Number(limit) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch leads' });
  }
});

// ── GET SINGLE LEAD ───────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .eq('id', req.params.id)
      .eq('business_id', req.user.business_id)
      .single();
    if (error || !data) return res.status(404).json({ error: 'Lead not found' });
    res.json({ lead: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch lead' });
  }
});

// ── CREATE LEAD (webhook or manual) ───────────────
router.post('/', async (req, res) => {
  const {
    name, phone, email, source, interest, budget, locality,
    property_type, message, score
  } = req.body;

  if (!name || !phone) return res.status(400).json({ error: 'Name and phone required' });

  try {
    const { data, error } = await supabase
      .from('leads')
      .insert({
        business_id: req.user.business_id,
        name, phone, email, source: source || 'manual',
        interest, budget, locality, property_type, message,
        score: score || 50,
        status: 'new',
        last_contact: new Date(),
      })
      .select()
      .single();

    if (error) throw error;
    res.status(201).json({ lead: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create lead' });
  }
});

// ── UPDATE LEAD ───────────────────────────────────
router.put('/:id', async (req, res) => {
  const allowed = ['name','phone','email','status','interest','budget',
                   'locality','property_type','score','notes','assigned_to'];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });
  updates.updated_at = new Date();

  try {
    const { data, error } = await supabase
      .from('leads')
      .update(updates)
      .eq('id', req.params.id)
      .eq('business_id', req.user.business_id)
      .select()
      .single();
    if (error) throw error;
    res.json({ lead: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update lead' });
  }
});

// ── DELETE LEAD ───────────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    const { error } = await supabase
      .from('leads')
      .delete()
      .eq('id', req.params.id)
      .eq('business_id', req.user.business_id);
    if (error) throw error;
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete lead' });
  }
});

// ── FOLLOW-UP LEADS ───────────────────────────────
router.get('/filter/followup', async (req, res) => {
  const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  try {
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .eq('business_id', req.user.business_id)
      .in('status', ['new', 'contacted'])
      .lt('last_contact', cutoff)
      .order('last_contact', { ascending: true })
      .limit(20);
    if (error) throw error;
    res.json({ leads: data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch follow-up leads' });
  }
});

// ── STATS SUMMARY ─────────────────────────────────
router.get('/stats/summary', async (req, res) => {
  try {
    const bizId = req.user.business_id;
    const [total, newToday, converted, followup] = await Promise.all([
      supabase.from('leads').select('id', { count: 'exact', head: true }).eq('business_id', bizId),
      supabase.from('leads').select('id', { count: 'exact', head: true })
        .eq('business_id', bizId)
        .gte('created_at', new Date(Date.now() - 86400000).toISOString()),
      supabase.from('leads').select('id', { count: 'exact', head: true })
        .eq('business_id', bizId).eq('status', 'converted'),
      supabase.from('leads').select('id', { count: 'exact', head: true })
        .eq('business_id', bizId)
        .in('status', ['new', 'contacted'])
        .lt('last_contact', new Date(Date.now() - 86400000).toISOString()),
    ]);

    res.json({
      total: total.count || 0,
      new_today: newToday.count || 0,
      converted: converted.count || 0,
      followup_needed: followup.count || 0,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

module.exports = router;
