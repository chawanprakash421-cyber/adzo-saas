require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();

// ── SECURITY ─────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: [
    process.env.FRONTEND_URL,
    'http://localhost:5173',
    'http://localhost:3000',
  ],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));

// ── RATE LIMITING ─────────────────────────────────
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, standardHeaders: true });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: { error: 'Too many attempts' } });
const aiLimiter = rateLimit({ windowMs: 60 * 1000, max: 15, message: { error: 'AI rate limit: 15 req/min' } });

app.use(limiter);
app.use(express.json({ limit: '2mb' }));

// ── HEALTH CHECK ──────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', version: '2.0.0', timestamp: new Date().toISOString() });
});

// ── ROUTES ────────────────────────────────────────
app.use('/api/auth', authLimiter, require('./routes/auth'));
app.use('/api/leads', require('./routes/leads'));
app.use('/api/content', aiLimiter, require('./routes/content'));
app.use('/api/campaigns', require('./routes/campaigns'));
app.use('/api/wallet', require('./routes/wallet'));
app.use('/api/admin', require('./routes/admin'));

// ── WEBHOOK: Lead from ad click ───────────────────
app.post('/webhook/lead', express.json(), async (req, res) => {
  // Receives lead from n8n after ad click → stores in Supabase
  const supabase = require('./db/supabase');
  const { business_id, name, phone, email, source, interest, locality, budget } = req.body;
  if (!business_id || !phone) return res.status(400).json({ error: 'Missing required fields' });

  try {
    const { data, error } = await supabase.from('leads').insert({
      business_id, name, phone, email, source: source || 'webhook',
      interest, locality, budget, status: 'new', score: 50,
      last_contact: new Date(),
    }).select().single();
    if (error) throw error;
    res.status(201).json({ lead: data });
  } catch (err) {
    res.status(500).json({ error: 'Webhook lead creation failed' });
  }
});

// ── 404 HANDLER ───────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
});

// ── ERROR HANDLER ─────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// ── START ─────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Adzo API running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV}`);
});
